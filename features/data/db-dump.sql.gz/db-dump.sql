-- MySQL dump 10.13  Distrib 5.1.63, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: omeka
-- ------------------------------------------------------
-- Server version	5.1.63-0ubuntu0.10.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `omeka_collections`
--

DROP TABLE IF EXISTS `omeka_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_collections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `collectors` text COLLATE utf8_unicode_ci,
  `public` tinyint(4) NOT NULL,
  `featured` tinyint(4) NOT NULL,
  `added` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `public` (`public`),
  KEY `featured` (`featured`),
  KEY `owner_id` (`owner_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_collections`
--

LOCK TABLES `omeka_collections` WRITE;
/*!40000 ALTER TABLE `omeka_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_data_types`
--

DROP TABLE IF EXISTS `omeka_data_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_data_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_data_types`
--

LOCK TABLES `omeka_data_types` WRITE;
/*!40000 ALTER TABLE `omeka_data_types` DISABLE KEYS */;
INSERT INTO `omeka_data_types` VALUES (1,'Text','A long, typically multi-line text string. Up to 65535 characters.'),(2,'Tiny Text','A short, typically one-line text string. Up to 255 characters.'),(3,'Date Range','A date range, begin to end. In format yyyy-mm-dd yyyy-mm-dd.'),(4,'Integer','Set of numbers consisting of the natural numbers including 0 (0, 1, 2, 3, ...) and their negatives (0, âˆ’1, âˆ’2, âˆ’3, ...).'),(9,'Date','A date in format yyyy-mm-dd'),(10,'Date Time','A date and time combination in the format: yyyy-mm-dd hh:mm:ss');
/*!40000 ALTER TABLE `omeka_data_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_element_sets`
--

DROP TABLE IF EXISTS `omeka_element_sets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_element_sets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `record_type_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `record_type_id` (`record_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_element_sets`
--

LOCK TABLES `omeka_element_sets` WRITE;
/*!40000 ALTER TABLE `omeka_element_sets` DISABLE KEYS */;
INSERT INTO `omeka_element_sets` VALUES (1,1,'Dublin Core','The Dublin Core metadata element set. These elements are common to all Omeka resources, including items, files, collections, exhibits, and entities. See http://dublincore.org/documents/dces/.'),(3,2,'Item Type Metadata','The item type metadata element set, consisting of all item type elements bundled with Omeka and all item type elements created by an administrator.'),(4,3,'Omeka Legacy File','The metadata element set that, in addition to the Dublin Core element set, was included in the `files` table in previous versions of Omeka. These elements are common to all Omeka files. This set may be deprecated in future versions.'),(5,3,'Omeka Image File','The metadata element set that was included in the `files_images` table in previous versions of Omeka. These elements are common to all image files.'),(6,3,'Omeka Video File','The metadata element set that was included in the `files_videos` table in previous versions of Omeka. These elements are common to all video files.');
/*!40000 ALTER TABLE `omeka_element_sets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_element_texts`
--

DROP TABLE IF EXISTS `omeka_element_texts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_element_texts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `record_id` int(10) unsigned NOT NULL,
  `record_type_id` int(10) unsigned NOT NULL,
  `element_id` int(10) unsigned NOT NULL,
  `html` tinyint(4) NOT NULL,
  `text` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `record_id` (`record_id`),
  KEY `record_type_id` (`record_type_id`),
  KEY `element_id` (`element_id`),
  FULLTEXT KEY `text` (`text`)
) ENGINE=MyISAM AUTO_INCREMENT=901 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_element_texts`
--

LOCK TABLES `omeka_element_texts` WRITE;
/*!40000 ALTER TABLE `omeka_element_texts` DISABLE KEYS */;
INSERT INTO `omeka_element_texts` VALUES (347,120,2,50,0,'display'),(348,120,2,38,0,'<kml xmlns=\"http://earth.google.com/kml/2.0\"><Folder><name>OpenLayers export</name><description>Exported on Tue Sep 11 2012 14:14:42 GMT-0400 (EDT)</description><Placemark><name>OpenLayers.Feature.Vector_160</name><description>No description available</description><Polygon><outerBoundaryIs><LinearRing><coordinates>-6555239.5448242,5102504.5113818 -8883817.1741797,3850160.2401318 -9020792.3288477,5493862.0961475 -6555239.5448242,5102504.5113818</coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark></Folder></kml>|4|-7788015.936836|4672011.1681396|osm\r\n'),(389,133,2,50,0,'multimodal'),(390,133,2,38,0,'<kml xmlns=\"http://earth.google.com/kml/2.0\"><Folder><name>OpenLayers export</name><description>Exported on Tue Sep 11 2012 14:33:23 GMT-0400 (EDT)</description><Placemark><name>OpenLayers.Feature.Vector_157</name><description>No description available</description><Point><coordinates>-6594375.3033008,6117100.9608124</coordinates></Point></Placemark></Folder></kml>||||osm\r\nA pointed question');
/*!40000 ALTER TABLE `omeka_element_texts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_elements`
--

DROP TABLE IF EXISTS `omeka_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_elements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `record_type_id` int(10) unsigned NOT NULL,
  `data_type_id` int(10) unsigned NOT NULL,
  `element_set_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_element_set_id` (`element_set_id`,`name`),
  UNIQUE KEY `order_element_set_id` (`element_set_id`,`order`),
  KEY `record_type_id` (`record_type_id`),
  KEY `data_type_id` (`data_type_id`),
  KEY `element_set_id` (`element_set_id`)
) ENGINE=MyISAM AUTO_INCREMENT=86 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_elements`
--

LOCK TABLES `omeka_elements` WRITE;
/*!40000 ALTER TABLE `omeka_elements` DISABLE KEYS */;
INSERT INTO `omeka_elements` VALUES (1,2,1,3,NULL,'Text','Any textual data included in the document.'),(2,2,2,3,NULL,'Interviewer','The person(s) performing the interview.'),(3,2,2,3,NULL,'Interviewee','The person(s) being interviewed.'),(4,2,2,3,NULL,'Location','The location of the interview.'),(5,2,1,3,NULL,'Transcription','Any written text transcribed from a sound.'),(6,2,2,3,NULL,'Local URL','The URL of the local directory containing all assets of the website.'),(7,2,2,3,NULL,'Original Format','If the image is of an object, state the type of object, such as painting, sculpture, paper, photo, and additional data'),(10,2,2,3,NULL,'Physical Dimensions','The actual physical size of the original image.'),(11,2,2,3,NULL,'Duration','Length of time involved (seconds, minutes, hours, days, class periods, etc.)'),(12,2,2,3,NULL,'Compression','Type/rate of compression for moving image file (i.e. MPEG-4)'),(13,2,2,3,NULL,'Producer','Name (or names) of the person who produced the video.'),(14,2,2,3,NULL,'Director','Name (or names) of the person who produced the video.'),(15,2,2,3,NULL,'Bit Rate/Frequency','Rate at which bits are transferred (i.e. 96 kbit/s would be FM quality audio)'),(16,2,2,3,NULL,'Time Summary','A summary of an interview given for different time stamps throughout the interview'),(17,2,1,3,NULL,'Email Body','The main body of the email, including all replied and forwarded text and headers.'),(18,2,2,3,NULL,'Subject Line','The content of the subject line of the email.'),(19,2,2,3,NULL,'From','The name and email address of the person sending the email.'),(20,2,2,3,NULL,'To','The name(s) and email address(es) of the person to whom the email was sent.'),(21,2,2,3,NULL,'CC','The name(s) and email address(es) of the person to whom the email was carbon copied.'),(22,2,2,3,NULL,'BCC','The name(s) and email address(es) of the person to whom the email was blind carbon copied.'),(23,2,2,3,NULL,'Number of Attachments','The number of attachments to the email.'),(24,2,1,3,NULL,'Standards',''),(25,2,1,3,NULL,'Objectives',''),(26,2,1,3,NULL,'Materials',''),(27,2,1,3,NULL,'Lesson Plan Text',''),(28,2,2,3,NULL,'URL',''),(29,2,2,3,NULL,'Event Type',''),(30,2,1,3,NULL,'Participants','Names of individuals or groups participating in the event.'),(31,2,9,3,NULL,'Birth Date',''),(32,2,2,3,NULL,'Birthplace',''),(33,2,9,3,NULL,'Death Date',''),(34,2,2,3,NULL,'Occupation',''),(35,2,1,3,NULL,'Biographical Text',''),(36,2,1,3,NULL,'Bibliography',''),(37,1,2,1,8,'Contributor','An entity responsible for making contributions to the resource. Examples of a Contributor include a person, an organization, or a service. Typically, the name of a Contributor should be used to indicate the entity.'),(38,1,2,1,15,'Coverage','The spatial or temporal topic of the resource, the spatial applicability of the resource, or the jurisdiction under which the resource is relevant. Spatial topic and spatial applicability may be a named place or a location specified by its geographic coordinates. Temporal topic may be a named period, date, or date range. A jurisdiction may be a named administrative entity or a geographic place to which the resource applies. Recommended best practice is to use a controlled vocabulary such as the Thesaurus of Geographic Names [TGN]. Where appropriate, named places or time periods can be used in preference to numeric identifiers such as sets of coordinates or date ranges.'),(39,1,2,1,4,'Creator','An entity primarily responsible for making the resource. Examples of a Creator include a person, an organization, or a service. Typically, the name of a Creator should be used to indicate the entity.'),(40,1,2,1,7,'Date','A point or period of time associated with an event in the lifecycle of the resource. Date may be used to express temporal information at any level of granularity. Recommended best practice is to use an encoding scheme, such as the W3CDTF profile of ISO 8601 [W3CDTF].'),(41,1,1,1,3,'Description','An account of the resource. Description may include but is not limited to: an abstract, a table of contents, a graphical representation, or a free-text account of the resource.'),(42,1,2,1,11,'Format','The file format, physical medium, or dimensions of the resource. Examples of dimensions include size and duration. Recommended best practice is to use a controlled vocabulary such as the list of Internet Media Types [MIME].'),(43,1,2,1,14,'Identifier','An unambiguous reference to the resource within a given context. Recommended best practice is to identify the resource by means of a string conforming to a formal identification system.'),(44,1,2,1,12,'Language','A language of the resource. Recommended best practice is to use a controlled vocabulary such as RFC 4646 [RFC4646].'),(45,1,2,1,6,'Publisher','An entity responsible for making the resource available. Examples of a Publisher include a person, an organization, or a service. Typically, the name of a Publisher should be used to indicate the entity.'),(46,1,2,1,10,'Relation','A related resource. Recommended best practice is to identify the related resource by means of a string conforming to a formal identification system.'),(47,1,2,1,9,'Rights','Information about rights held in and over the resource. Typically, rights information includes a statement about various property rights associated with the resource, including intellectual property rights.'),(48,1,2,1,5,'Source','A related resource from which the described resource is derived. The described resource may be derived from the related resource in whole or in part. Recommended best practice is to identify the related resource by means of a string conforming to a formal identification system.'),(49,1,2,1,2,'Subject','The topic of the resource. Typically, the subject will be represented using keywords, key phrases, or classification codes. Recommended best practice is to use a controlled vocabulary. To describe the spatial or temporal topic of the resource, use the Coverage element.'),(50,1,2,1,1,'Title','A name given to the resource. Typically, a Title will be a name by which the resource is formally known.'),(51,1,2,1,13,'Type','The nature or genre of the resource. Recommended best practice is to use a controlled vocabulary such as the DCMI Type Vocabulary [DCMITYPE]. To describe the file format, physical medium, or dimensions of the resource, use the Format element.'),(58,3,1,4,1,'Additional Creator',''),(59,3,1,4,2,'Transcriber',''),(60,3,1,4,3,'Producer',''),(61,3,1,4,4,'Render Device',''),(62,3,1,4,5,'Render Details',''),(63,3,10,4,6,'Capture Date',''),(64,3,1,4,7,'Capture Device',''),(65,3,1,4,8,'Capture Details',''),(66,3,1,4,9,'Change History',''),(67,3,1,4,10,'Watermark',''),(69,3,1,4,12,'Encryption',''),(70,3,1,4,13,'Compression',''),(71,3,1,4,14,'Post Processing',''),(72,3,4,5,1,'Width',''),(73,3,4,5,2,'Height',''),(74,3,4,5,3,'Bit Depth',''),(75,3,4,5,4,'Channels',''),(76,3,1,5,5,'Exif String',''),(77,3,1,5,6,'Exif Array',''),(78,3,1,5,7,'IPTC String',''),(79,3,1,5,8,'IPTC Array',''),(80,3,4,6,1,'Bitrate',''),(81,3,4,6,2,'Duration',''),(82,3,4,6,3,'Sample Rate',''),(83,3,1,6,4,'Codec',''),(84,3,4,6,5,'Width',''),(85,3,4,6,6,'Height','');
/*!40000 ALTER TABLE `omeka_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_entities`
--

DROP TABLE IF EXISTS `omeka_entities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_entities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` text COLLATE utf8_unicode_ci,
  `middle_name` text COLLATE utf8_unicode_ci,
  `last_name` text COLLATE utf8_unicode_ci,
  `email` text COLLATE utf8_unicode_ci,
  `institution` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_entities`
--

LOCK TABLES `omeka_entities` WRITE;
/*!40000 ALTER TABLE `omeka_entities` DISABLE KEYS */;
INSERT INTO `omeka_entities` VALUES (1,'Super',NULL,'User','neatline@scholarslab.org',NULL);
/*!40000 ALTER TABLE `omeka_entities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_entities_relations`
--

DROP TABLE IF EXISTS `omeka_entities_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_entities_relations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entity_id` int(10) unsigned DEFAULT NULL,
  `relation_id` int(10) unsigned DEFAULT NULL,
  `relationship_id` int(10) unsigned DEFAULT NULL,
  `type` enum('Item','Collection','Exhibit') COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `relation_type` (`type`),
  KEY `relation` (`relation_id`),
  KEY `relationship` (`relationship_id`)
) ENGINE=MyISAM AUTO_INCREMENT=282 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_entities_relations`
--

LOCK TABLES `omeka_entities_relations` WRITE;
/*!40000 ALTER TABLE `omeka_entities_relations` DISABLE KEYS */;
INSERT INTO `omeka_entities_relations` VALUES (23,1,23,1,'Item','2012-08-30 19:45:58'),(24,1,24,1,'Item','2012-08-30 19:46:40'),(25,1,25,1,'Item','2012-08-30 19:49:21'),(26,1,26,1,'Item','2012-08-30 19:52:16'),(27,1,27,1,'Item','2012-08-30 19:52:35'),(28,1,28,1,'Item','2012-08-30 19:52:52'),(29,1,29,1,'Item','2012-08-30 19:53:10'),(30,1,30,1,'Item','2012-08-30 19:53:29'),(31,1,31,1,'Item','2012-08-30 19:53:44'),(32,1,32,1,'Item','2012-08-30 19:54:03'),(33,1,33,1,'Item','2012-08-30 19:54:26'),(34,1,34,1,'Item','2012-08-30 19:54:44'),(35,1,35,1,'Item','2012-08-30 19:55:35'),(36,1,36,1,'Item','2012-08-30 19:55:48'),(37,1,37,1,'Item','2012-08-30 19:56:01'),(38,1,38,1,'Item','2012-08-30 19:57:12'),(39,1,39,1,'Item','2012-08-30 19:59:18'),(40,1,40,1,'Item','2012-08-30 19:59:27'),(41,1,41,1,'Item','2012-08-30 20:00:09'),(42,1,42,1,'Item','2012-08-30 20:00:22'),(43,1,43,1,'Item','2012-08-30 20:00:40'),(44,1,44,1,'Item','2012-08-30 20:01:12'),(45,1,45,1,'Item','2012-08-30 20:15:41'),(47,1,47,1,'Item','2012-09-04 21:08:22'),(48,1,48,1,'Item','2012-09-04 21:09:37'),(49,1,49,1,'Item','2012-09-04 21:09:52'),(50,1,50,1,'Item','2012-09-04 21:12:03'),(51,1,51,1,'Item','2012-09-04 21:15:49'),(52,1,52,1,'Item','2012-09-04 21:16:02'),(53,1,53,1,'Item','2012-09-04 21:16:16'),(54,1,54,1,'Item','2012-09-04 21:16:31'),(55,1,55,1,'Item','2012-09-04 21:16:46'),(56,1,56,1,'Item','2012-09-04 21:17:02'),(57,1,57,1,'Item','2012-09-04 21:17:19'),(58,1,58,1,'Item','2012-09-04 21:17:36'),(59,1,59,1,'Item','2012-09-04 21:17:48'),(60,1,60,1,'Item','2012-09-04 21:18:40'),(61,1,61,1,'Item','2012-09-04 21:18:55'),(62,1,62,1,'Item','2012-09-04 21:19:11'),(63,1,63,1,'Item','2012-09-04 21:20:24'),(64,1,64,1,'Item','2012-09-04 21:22:39'),(65,1,65,1,'Item','2012-09-04 21:22:47'),(66,1,66,1,'Item','2012-09-04 21:23:27'),(67,1,67,1,'Item','2012-09-04 21:23:38'),(68,1,68,1,'Item','2012-09-04 21:23:56'),(69,1,69,1,'Item','2012-09-04 21:24:30'),(79,1,79,1,'Item','2012-09-06 16:40:28'),(80,1,80,1,'Item','2012-09-06 17:13:25'),(81,1,81,1,'Item','2012-09-06 17:42:09'),(76,1,76,1,'Item','2012-09-04 22:49:29'),(77,1,77,1,'Item','2012-09-04 22:54:46'),(78,1,78,1,'Item','2012-09-04 22:56:12'),(82,1,82,1,'Item','2012-09-06 19:01:43'),(83,1,83,1,'Item','2012-09-06 19:08:08'),(84,1,84,1,'Item','2012-09-06 19:11:15'),(85,1,85,1,'Item','2012-09-06 19:24:51'),(86,1,86,1,'Item','2012-09-06 19:30:08'),(87,1,87,1,'Item','2012-09-06 19:37:48'),(88,1,88,1,'Item','2012-09-06 19:55:30'),(89,1,89,1,'Item','2012-09-06 20:03:03'),(90,1,90,1,'Item','2012-09-06 20:56:58'),(91,1,91,1,'Item','2012-09-06 21:55:32'),(92,1,92,1,'Item','2012-09-06 21:58:39'),(93,1,93,1,'Item','2012-09-10 22:20:39'),(94,1,94,1,'Item','2012-09-10 22:21:00'),(95,1,95,1,'Item','2012-09-10 22:21:16'),(96,1,96,1,'Item','2012-09-10 22:21:32'),(97,1,97,1,'Item','2012-09-10 22:23:52'),(98,1,98,1,'Item','2012-09-10 22:24:05'),(99,1,99,1,'Item','2012-09-10 22:24:19'),(100,1,100,1,'Item','2012-09-10 22:24:45'),(101,1,101,1,'Item','2012-09-10 22:34:54'),(102,1,102,1,'Item','2012-09-10 22:36:01'),(103,1,103,1,'Item','2012-09-10 22:37:09'),(104,1,104,1,'Item','2012-09-10 22:38:19'),(105,1,105,1,'Item','2012-09-10 22:39:27'),(106,1,106,1,'Item','2012-09-10 22:39:41'),(107,1,107,1,'Item','2012-09-10 22:40:52'),(108,1,108,1,'Item','2012-09-10 22:44:02'),(109,1,109,1,'Item','2012-09-10 22:45:09'),(110,1,110,1,'Item','2012-09-10 22:45:21'),(111,1,111,1,'Item','2012-09-10 22:45:35'),(112,1,112,1,'Item','2012-09-10 22:46:00'),(113,1,113,1,'Item','2012-09-11 18:26:21'),(114,1,114,1,'Item','2012-09-11 18:29:24'),(115,1,115,1,'Item','2012-09-11 18:34:48'),(116,1,116,1,'Item','2012-09-11 18:38:41'),(117,1,117,1,'Item','2012-09-11 18:39:41'),(118,1,118,1,'Item','2012-09-11 19:47:49'),(120,1,120,1,'Item','2012-09-11 20:00:51'),(121,1,120,2,'Item','2012-09-11 20:01:30'),(122,1,121,1,'Item','2012-09-11 20:02:40'),(123,1,122,1,'Item','2012-09-11 20:02:55'),(124,1,123,1,'Item','2012-09-11 20:04:10'),(125,1,124,1,'Item','2012-09-11 20:04:27'),(126,1,125,1,'Item','2012-09-11 20:05:46'),(127,1,126,1,'Item','2012-09-11 20:06:02'),(128,1,127,1,'Item','2012-09-11 20:06:18'),(129,1,128,1,'Item','2012-09-11 20:09:53'),(130,1,129,1,'Item','2012-09-11 20:10:10'),(131,1,130,1,'Item','2012-09-11 20:10:25'),(132,1,131,1,'Item','2012-09-11 20:11:30'),(133,1,132,1,'Item','2012-09-11 20:11:57'),(134,1,133,1,'Item','2012-09-11 20:20:29'),(135,1,134,1,'Item','2012-09-11 20:26:19'),(136,1,135,1,'Item','2012-09-11 20:31:25'),(137,1,136,1,'Item','2012-09-11 20:40:05'),(138,1,137,1,'Item','2012-09-11 20:40:50'),(139,1,138,1,'Item','2012-09-11 20:41:01'),(140,1,139,1,'Item','2012-09-11 20:42:17'),(141,1,140,1,'Item','2012-09-11 20:42:34'),(142,1,141,1,'Item','2012-09-11 20:43:45'),(143,1,142,1,'Item','2012-09-11 20:44:03'),(144,1,143,1,'Item','2012-09-11 20:44:17'),(145,1,144,1,'Item','2012-09-11 20:47:20'),(146,1,145,1,'Item','2012-09-11 21:07:35'),(147,1,146,1,'Item','2012-09-11 21:07:45'),(148,1,147,1,'Item','2012-09-11 21:08:46'),(149,1,148,1,'Item','2012-09-11 21:09:10'),(150,1,149,1,'Item','2012-09-11 21:21:51'),(151,1,150,1,'Item','2012-09-11 21:22:08'),(152,1,151,1,'Item','2012-09-11 21:24:40'),(153,1,152,1,'Item','2012-09-11 21:26:03'),(154,1,153,1,'Item','2012-09-11 21:26:18'),(155,1,154,1,'Item','2012-09-11 21:28:25'),(156,1,155,1,'Item','2012-09-11 21:28:39'),(157,1,156,1,'Item','2012-09-11 21:28:55'),(158,1,157,1,'Item','2012-09-11 21:29:11'),(159,1,158,1,'Item','2012-09-11 21:30:24'),(160,1,159,1,'Item','2012-09-11 21:30:38'),(161,1,160,1,'Item','2012-09-11 21:30:55'),(162,1,161,1,'Item','2012-09-11 21:34:04'),(163,1,162,1,'Item','2012-09-11 21:34:14'),(164,1,163,1,'Item','2012-09-11 21:34:28'),(165,1,164,1,'Item','2012-09-11 21:34:41'),(166,1,165,1,'Item','2012-09-11 21:35:07'),(167,1,166,1,'Item','2012-09-11 21:41:50'),(168,1,167,1,'Item','2012-09-11 21:42:04'),(169,1,168,1,'Item','2012-09-11 21:43:12'),(170,1,169,1,'Item','2012-09-11 21:43:28'),(171,1,170,1,'Item','2012-09-11 21:44:39'),(172,1,171,1,'Item','2012-09-11 21:44:53'),(173,1,172,1,'Item','2012-09-11 21:45:10'),(174,1,173,1,'Item','2012-09-11 21:46:30'),(175,1,174,1,'Item','2012-09-11 21:46:41'),(176,1,175,1,'Item','2012-09-11 21:46:57'),(177,1,176,1,'Item','2012-09-11 21:47:12'),(178,1,177,1,'Item','2012-09-11 21:47:39'),(179,1,178,1,'Item','2012-09-12 15:03:54'),(180,1,179,1,'Item','2012-09-12 15:04:08'),(181,1,180,1,'Item','2012-09-12 15:05:19'),(182,1,181,1,'Item','2012-09-12 15:05:35'),(183,1,182,1,'Item','2012-09-12 15:06:54'),(184,1,183,1,'Item','2012-09-12 15:07:09'),(185,1,184,1,'Item','2012-09-12 15:07:27'),(186,1,185,1,'Item','2012-09-12 15:08:51'),(187,1,186,1,'Item','2012-09-12 15:09:02'),(188,1,187,1,'Item','2012-09-12 15:09:16'),(189,1,188,1,'Item','2012-09-12 15:09:30'),(190,1,189,1,'Item','2012-09-12 15:09:56'),(191,1,190,1,'Item','2012-09-12 15:41:30'),(192,1,191,1,'Item','2012-09-12 15:41:55'),(193,1,192,1,'Item','2012-09-12 15:42:27'),(194,1,193,1,'Item','2012-09-12 15:42:58'),(195,1,194,1,'Item','2012-09-12 15:43:08'),(196,1,195,1,'Item','2012-09-12 15:43:27'),(197,1,196,1,'Item','2012-09-12 15:46:38'),(198,1,197,1,'Item','2012-09-12 15:46:52'),(199,1,198,1,'Item','2012-09-12 15:47:56'),(200,1,199,1,'Item','2012-09-12 15:48:12'),(201,1,200,1,'Item','2012-09-12 15:48:26'),(202,1,201,1,'Item','2012-09-12 15:48:44'),(203,1,202,1,'Item','2012-09-12 15:49:58'),(204,1,203,1,'Item','2012-09-12 15:50:10'),(205,1,204,1,'Item','2012-09-12 15:50:30'),(206,1,205,1,'Item','2012-09-12 15:51:49'),(207,1,206,1,'Item','2012-09-12 15:52:02'),(208,1,207,1,'Item','2012-09-12 15:52:21'),(209,1,208,1,'Item','2012-09-12 15:52:32'),(210,1,209,1,'Item','2012-09-12 15:53:00'),(211,1,210,1,'Item','2012-09-12 15:54:19'),(212,1,211,1,'Item','2012-09-12 15:54:35'),(213,1,212,1,'Item','2012-09-12 15:54:48'),(214,1,213,1,'Item','2012-09-12 15:55:05'),(215,1,214,1,'Item','2012-09-12 15:56:22'),(216,1,215,1,'Item','2012-09-12 15:56:35'),(217,1,216,1,'Item','2012-09-12 15:56:58'),(218,1,217,1,'Item','2012-09-12 15:58:15'),(219,1,218,1,'Item','2012-09-12 15:58:24'),(220,1,219,1,'Item','2012-09-12 15:58:43'),(221,1,220,1,'Item','2012-09-12 15:58:54'),(222,1,221,1,'Item','2012-09-12 15:59:23'),(223,1,222,1,'Item','2012-09-12 16:11:05'),(224,1,223,1,'Item','2012-09-12 16:11:21'),(225,1,224,1,'Item','2012-09-12 16:12:29'),(226,1,225,1,'Item','2012-09-12 16:12:47'),(227,1,226,1,'Item','2012-09-12 16:14:08'),(228,1,227,1,'Item','2012-09-12 16:14:24'),(229,1,228,1,'Item','2012-09-12 16:14:44'),(230,1,229,1,'Item','2012-09-12 16:16:03'),(231,1,230,1,'Item','2012-09-12 16:16:14'),(232,1,231,1,'Item','2012-09-12 16:16:36'),(233,1,232,1,'Item','2012-09-12 16:16:49'),(234,1,233,1,'Item','2012-09-12 16:17:17'),(235,1,234,1,'Item','2012-09-12 16:32:51'),(236,1,235,1,'Item','2012-09-12 16:33:08'),(237,1,236,1,'Item','2012-09-12 16:34:17'),(238,1,237,1,'Item','2012-09-12 16:34:36'),(239,1,238,1,'Item','2012-09-12 16:34:58'),(240,1,239,1,'Item','2012-09-12 16:35:12'),(241,1,240,1,'Item','2012-09-12 16:35:39'),(242,1,241,1,'Item','2012-09-12 16:37:05'),(243,1,242,1,'Item','2012-09-12 16:37:16'),(244,1,243,1,'Item','2012-09-12 16:37:36'),(245,1,244,1,'Item','2012-09-12 16:37:49'),(246,1,245,1,'Item','2012-09-12 16:38:20'),(247,1,246,1,'Item','2012-09-12 16:39:56'),(248,1,247,1,'Item','2012-09-12 16:40:13'),(249,1,248,1,'Item','2012-09-12 16:40:41'),(250,1,249,1,'Item','2012-09-12 17:46:17'),(251,1,250,1,'Item','2012-09-12 17:46:50'),(252,1,251,1,'Item','2012-09-12 17:47:22'),(253,1,252,1,'Item','2012-09-12 17:57:03'),(254,1,253,1,'Item','2012-09-12 17:58:14'),(255,1,254,1,'Item','2012-09-12 19:09:29'),(256,1,255,1,'Item','2012-09-12 22:33:02'),(257,1,256,1,'Item','2012-09-13 19:19:11'),(258,1,257,1,'Item','2012-09-13 19:20:24'),(259,1,258,1,'Item','2012-09-13 19:20:43'),(260,1,259,1,'Item','2012-09-13 19:20:58'),(261,1,260,1,'Item','2012-09-13 19:21:18'),(262,1,261,1,'Item','2012-09-13 19:21:50'),(263,1,262,1,'Item','2012-09-13 19:22:04'),(264,1,263,1,'Item','2012-09-13 19:22:23'),(265,1,264,1,'Item','2012-09-13 19:22:46'),(266,1,265,1,'Item','2012-09-13 19:22:57'),(267,1,266,1,'Item','2012-09-13 19:23:17'),(268,1,267,1,'Item','2012-09-13 19:23:30'),(269,1,268,1,'Item','2012-09-13 19:24:01'),(270,1,269,1,'Item','2012-09-13 19:38:23'),(271,1,270,1,'Item','2012-09-13 19:38:42'),(272,1,271,1,'Item','2012-09-13 19:38:57'),(273,1,272,1,'Item','2012-09-13 19:39:16'),(274,1,273,1,'Item','2012-09-13 19:39:43'),(275,1,274,1,'Item','2012-09-13 19:39:57'),(276,1,275,1,'Item','2012-09-13 19:40:17'),(277,1,276,1,'Item','2012-09-13 19:40:44'),(278,1,277,1,'Item','2012-09-13 19:40:56'),(279,1,278,1,'Item','2012-09-13 19:41:17'),(280,1,279,1,'Item','2012-09-13 19:41:30'),(281,1,280,1,'Item','2012-09-13 19:42:02');
/*!40000 ALTER TABLE `omeka_entities_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_entity_relationships`
--

DROP TABLE IF EXISTS `omeka_entity_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_entity_relationships` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_entity_relationships`
--

LOCK TABLES `omeka_entity_relationships` WRITE;
/*!40000 ALTER TABLE `omeka_entity_relationships` DISABLE KEYS */;
INSERT INTO `omeka_entity_relationships` VALUES (1,'added',NULL),(2,'modified',NULL),(3,'favorite',NULL),(4,'collector',NULL);
/*!40000 ALTER TABLE `omeka_entity_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_files`
--

DROP TABLE IF EXISTS `omeka_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `size` int(10) unsigned NOT NULL,
  `has_derivative_image` tinyint(1) NOT NULL,
  `authentication` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime_browser` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime_os` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_os` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `archive_filename` text COLLATE utf8_unicode_ci NOT NULL,
  `original_filename` text COLLATE utf8_unicode_ci NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `added` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `stored` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_files`
--

LOCK TABLES `omeka_files` WRITE;
/*!40000 ALTER TABLE `omeka_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_item_types`
--

DROP TABLE IF EXISTS `omeka_item_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_item_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_item_types`
--

LOCK TABLES `omeka_item_types` WRITE;
/*!40000 ALTER TABLE `omeka_item_types` DISABLE KEYS */;
INSERT INTO `omeka_item_types` VALUES (1,'Document','A resource containing textual data.  Note that facsimiles or images of texts are still of the genre text.'),(3,'Moving Image','A series of visual representations that, when shown in succession, impart an impression of motion.'),(4,'Oral History','A resource containing historical information obtained in interviews with persons having firsthand knowledge.'),(5,'Sound','A resource whose content is primarily intended to be rendered as audio.'),(6,'Still Image','A static visual representation. Examples of still images are: paintings, drawings, graphic designs, plans and maps.  Recommended best practice is to assign the type \"text\" to images of textual materials.'),(7,'Website','A resource comprising of a web page or web pages and all related assets ( such as images, sound and video files, etc. ).'),(8,'Event','A non-persistent, time-based occurrence.  Metadata for an event provides descriptive information that is the basis for discovery of the purpose, location, duration, and responsible agents associated with an event. Examples include an exhibition, webcast, conference, workshop, open day, performance, battle, trial, wedding, tea party, conflagration.'),(9,'Email','A resource containing textual messages and binary attachments sent electronically from one person to another or one person to many people.'),(10,'Lesson Plan','Instructional materials.'),(11,'Hyperlink','Title, URL, Description or annotation.'),(12,'Person','An individual, biographical data, birth and death, etc.'),(13,'Interactive Resource','A resource requiring interaction from the user to be understood, executed, or experienced. Examples include forms on Web pages, applets, multimedia learning objects, chat services, or virtual reality environments.');
/*!40000 ALTER TABLE `omeka_item_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_item_types_elements`
--

DROP TABLE IF EXISTS `omeka_item_types_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_item_types_elements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_type_id` int(10) unsigned NOT NULL,
  `element_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_type_id_element_id` (`item_type_id`,`element_id`),
  KEY `item_type_id` (`item_type_id`),
  KEY `element_id` (`element_id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_item_types_elements`
--

LOCK TABLES `omeka_item_types_elements` WRITE;
/*!40000 ALTER TABLE `omeka_item_types_elements` DISABLE KEYS */;
INSERT INTO `omeka_item_types_elements` VALUES (1,1,7,NULL),(2,1,1,NULL),(3,6,7,NULL),(6,6,10,NULL),(7,3,7,NULL),(8,3,11,NULL),(9,3,12,NULL),(10,3,13,NULL),(11,3,14,NULL),(12,3,5,NULL),(13,5,7,NULL),(14,5,11,NULL),(15,5,15,NULL),(16,5,5,NULL),(17,4,7,NULL),(18,4,11,NULL),(19,4,15,NULL),(20,4,5,NULL),(21,4,2,NULL),(22,4,3,NULL),(23,4,4,NULL),(24,4,16,NULL),(25,9,17,NULL),(26,9,18,NULL),(27,9,20,NULL),(28,9,19,NULL),(29,9,21,NULL),(30,9,22,NULL),(31,9,23,NULL),(32,10,24,NULL),(33,10,25,NULL),(34,10,26,NULL),(35,10,11,NULL),(36,10,27,NULL),(37,7,6,NULL),(38,11,28,NULL),(39,8,29,NULL),(40,8,30,NULL),(41,8,11,NULL),(42,12,31,NULL),(43,12,32,NULL),(44,12,33,NULL),(45,12,34,NULL),(46,12,35,NULL),(47,12,36,NULL);
/*!40000 ALTER TABLE `omeka_item_types_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_items`
--

DROP TABLE IF EXISTS `omeka_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_type_id` int(10) unsigned DEFAULT NULL,
  `collection_id` int(10) unsigned DEFAULT NULL,
  `featured` tinyint(4) NOT NULL,
  `public` tinyint(4) NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `added` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `item_type_id` (`item_type_id`),
  KEY `collection_id` (`collection_id`),
  KEY `public` (`public`),
  KEY `featured` (`featured`)
) ENGINE=MyISAM AUTO_INCREMENT=281 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_items`
--

LOCK TABLES `omeka_items` WRITE;
/*!40000 ALTER TABLE `omeka_items` DISABLE KEYS */;
INSERT INTO `omeka_items` VALUES (133,0,NULL,0,0,'2012-09-11 18:20:29','2012-09-11 18:20:29'),(120,0,NULL,0,0,'2012-09-11 18:01:30','2012-09-11 18:00:51');
/*!40000 ALTER TABLE `omeka_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_mime_element_set_lookup`
--

DROP TABLE IF EXISTS `omeka_mime_element_set_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_mime_element_set_lookup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `element_set_id` int(10) unsigned NOT NULL,
  `mime` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mime` (`mime`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_mime_element_set_lookup`
--

LOCK TABLES `omeka_mime_element_set_lookup` WRITE;
/*!40000 ALTER TABLE `omeka_mime_element_set_lookup` DISABLE KEYS */;
INSERT INTO `omeka_mime_element_set_lookup` VALUES (1,5,'image/bmp'),(2,5,'image/gif'),(3,5,'image/ief'),(4,5,'image/jpeg'),(5,5,'image/pict'),(6,5,'image/pjpeg'),(7,5,'image/png'),(8,5,'image/tiff'),(9,5,'image/vnd.rn-realflash'),(10,5,'image/vnd.rn-realpix'),(11,5,'image/vnd.wap.wbmp'),(12,5,'image/x-icon'),(13,5,'image/x-jg'),(14,5,'image/x-jps'),(15,5,'image/x-niff'),(16,5,'image/x-pcx'),(17,5,'image/x-pict'),(18,5,'image/x-quicktime'),(19,5,'image/x-rgb'),(20,5,'image/x-tiff'),(21,5,'image/x-windows-bmp'),(22,5,'image/x-xbitmap'),(23,5,'image/x-xbm'),(24,5,'image/x-xpixmap'),(25,5,'image/x-xwd'),(26,5,'image/x-xwindowdump'),(27,6,'video/x-msvideo'),(28,6,'video/avi'),(29,6,'video/msvideo'),(30,6,'video/x-mpeg'),(31,6,'video/x-ms-asf'),(32,6,'video/mpeg'),(33,6,'video/quicktime'),(34,6,'video/x-ms-wmv');
/*!40000 ALTER TABLE `omeka_mime_element_set_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_neatline_features`
--

DROP TABLE IF EXISTS `omeka_neatline_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_neatline_features` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `item_id` int(10) unsigned NOT NULL,
  `element_text_id` int(10) unsigned NOT NULL,
  `is_map` tinyint(1) NOT NULL DEFAULT '0',
  `geo` text COLLATE utf8_unicode_ci,
  `zoom` smallint(2) NOT NULL DEFAULT '3',
  `center_lon` decimal(20,7) NOT NULL DEFAULT '0.0000000',
  `center_lat` decimal(20,7) NOT NULL DEFAULT '0.0000000',
  `base_layer` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`,`element_text_id`)
) ENGINE=InnoDB AUTO_INCREMENT=381 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_neatline_features`
--

LOCK TABLES `omeka_neatline_features` WRITE;
/*!40000 ALTER TABLE `omeka_neatline_features` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_neatline_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_options`
--

DROP TABLE IF EXISTS `omeka_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_options`
--

LOCK TABLES `omeka_options` WRITE;
/*!40000 ALTER TABLE `omeka_options` DISABLE KEYS */;
INSERT INTO `omeka_options` VALUES (1,'omeka_version','1.5.3'),(2,'administrator_email','neatline@scholarslab.org'),(3,'copyright',''),(4,'site_title','NeatlineFeatures Travis CI'),(5,'author',''),(6,'description',''),(7,'thumbnail_constraint','200'),(8,'square_thumbnail_constraint','200'),(9,'fullsize_constraint','800'),(10,'per_page_admin','10'),(11,'per_page_public','10'),(12,'show_empty_elements','0'),(13,'path_to_convert','/usr/bin'),(14,'admin_theme','default'),(15,'public_theme','default'),(16,'file_extension_whitelist','aac,aif,aiff,asf,asx,avi,bmp,c,cc,class,css,divx,doc,docx,exe,gif,gz,gzip,h,ico,j2k,jp2,jpe,jpeg,jpg,m4a,mdb,mid,midi,mov,mp2,mp3,mp4,mpa,mpe,mpeg,mpg,mpp,odb,odc,odf,odg,odp,ods,odt,ogg, pdf,png,pot,pps,ppt,pptx,qt,ra,ram,rtf,rtx,swf,tar,tif,tiff,txt, wav,wax,wma,wmv,wmx,wri,xla,xls,xlsx,xlt,xlw,zip'),(17,'file_mime_type_whitelist','application/msword,application/ogg,application/pdf,application/rtf,application/vnd.ms-access,application/vnd.ms-excel,application/vnd.ms-powerpoint,application/vnd.ms-project,application/vnd.ms-write,application/vnd.oasis.opendocument.chart,application/vnd.oasis.opendocument.database,application/vnd.oasis.opendocument.formula,application/vnd.oasis.opendocument.graphics,application/vnd.oasis.opendocument.presentation,application/vnd.oasis.opendocument.spreadsheet,application/vnd.oasis.opendocument.text,application/x-ms-wmp,application/x-ogg,application/x-gzip,application/x-msdownload,application/x-shockwave-flash,application/x-tar,application/zip,audio/aac,audio/aiff,audio/mid,audio/midi,audio/mp3,audio/mp4,audio/mpeg,audio/mpeg3,audio/ogg,audio/wav,audio/wma,audio/x-aac,audio/x-aiff,audio/x-midi,audio/x-mp3,audio/x-mp4,audio/x-mpeg,audio/x-mpeg3,audio/x-mpegaudio,audio/x-ms-wax,audio/x-realaudio,audio/x-wav,audio/x-wma,image/bmp,image/gif,image/icon,image/jpeg,image/pjpeg,image/png,image/tiff,image/x-icon,image/x-ms-bmp,text/css,text/plain,text/richtext,text/rtf,video/asf,video/avi,video/divx,video/mp4,video/mpeg,video/msvideo,video/ogg,video/quicktime,video/x-ms-wmv,video/x-msvideo'),(18,'disable_default_file_validation',''),(19,'display_system_info','1'),(20,'tag_delimiter',','),(28,'omeka_update','a:2:{s:14:\"latest_version\";s:5:\"1.5.3\";s:12:\"last_updated\";i:1347556716;}');
/*!40000 ALTER TABLE `omeka_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_plugins`
--

DROP TABLE IF EXISTS `omeka_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_plugins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL,
  `version` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `active_idx` (`active`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_plugins`
--

LOCK TABLES `omeka_plugins` WRITE;
/*!40000 ALTER TABLE `omeka_plugins` DISABLE KEYS */;
INSERT INTO `omeka_plugins` VALUES (1,'NeatlineFeatures',1,'1.0.0.1');
/*!40000 ALTER TABLE `omeka_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_processes`
--

DROP TABLE IF EXISTS `omeka_processes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_processes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned DEFAULT NULL,
  `status` enum('starting','in progress','completed','paused','error','stopped') COLLATE utf8_unicode_ci NOT NULL,
  `args` text COLLATE utf8_unicode_ci NOT NULL,
  `started` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `stopped` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `pid` (`pid`),
  KEY `started` (`started`),
  KEY `stopped` (`stopped`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_processes`
--

LOCK TABLES `omeka_processes` WRITE;
/*!40000 ALTER TABLE `omeka_processes` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_processes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_record_types`
--

DROP TABLE IF EXISTS `omeka_record_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_record_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_record_types`
--

LOCK TABLES `omeka_record_types` WRITE;
/*!40000 ALTER TABLE `omeka_record_types` DISABLE KEYS */;
INSERT INTO `omeka_record_types` VALUES (1,'All','Elements, element sets, and element texts assigned to this record type relate to all possible records.'),(2,'Item','Elements, element sets, and element texts assigned to this record type relate to item records.'),(3,'File','Elements, element sets, and element texts assigned to this record type relate to file records.');
/*!40000 ALTER TABLE `omeka_record_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_schema_migrations`
--

DROP TABLE IF EXISTS `omeka_schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_schema_migrations` (
  `version` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_schema_migrations`
--

LOCK TABLES `omeka_schema_migrations` WRITE;
/*!40000 ALTER TABLE `omeka_schema_migrations` DISABLE KEYS */;
INSERT INTO `omeka_schema_migrations` VALUES ('20100401000000'),('20100810120000'),('20110113000000'),('20110124000001'),('20110301103900'),('20110328192100'),('20110426181300'),('20110601112200'),('20110627223000'),('20110824110000'),('20120112100000');
/*!40000 ALTER TABLE `omeka_schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_sessions`
--

DROP TABLE IF EXISTS `omeka_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_sessions` (
  `id` char(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `modified` bigint(20) DEFAULT NULL,
  `lifetime` int(11) DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_sessions`
--

LOCK TABLES `omeka_sessions` WRITE;
/*!40000 ALTER TABLE `omeka_sessions` DISABLE KEYS */;
INSERT INTO `omeka_sessions` VALUES ('004oetfnoqcl1nlb16n70udek3',1346349646,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('00vi5r3c7vlp3m6r5u04s4sbm3',1346785797,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('01mjncmgprfngps2ks8aj5cu45',1347558080,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('03f3vgt1ha9briq577q57s0b20',1346784065,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('03rjcnbqf5r7b5t68o45n8dui5',1347457900,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('052a19jspu31o3h6uenrhcea85',1347309502,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('07r9sqi7bpjht3jgclkdtr6dh3',1347458091,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('07tokdm25ueq53079a7lfai3n2',1347388289,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('09o2qvahtdghj0ie7q8m4cetp6',1347459412,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('0ae3jsa8p7d131l08u132veok4',1347309280,1209600,'flash|a:1:{s:6:\"status\";N;}'),('0ag7t4rj0lljmbntio84j5kpf6',1347557985,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('0c36gi8b75i1pn97bgjhhjsme4',1347457281,1209600,''),('0d0racifb49sorulec20809196',1347556882,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('0e27bnejg0cb9u69uio12mu6u7',1346349437,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('0e36e8biuqd5bu5359bo9el9q6',1347379087,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('0eldardl03tl5qqubeoc6dj071',1347459354,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('0n9r2j90a1nefbs2kplvnns1f4',1347391858,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('0plh5mm58lap1g65i10r9lad45',1346349316,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('1008me5936p6avr8pccol2c223',1347309570,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('10rthm132supvai1canpei7e54',1347557885,1209600,'flash|a:1:{s:6:\"status\";N;}'),('187lfvl5vqer7aiqoqc2amog02',1347457318,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('18ub9cru2c4ntg15e8betpu276',1347309964,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('1bhrrq378hivsbl7sj90iin1d3',1346783185,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('1c1klpn3rs8pi5sp0loumoal76',1346350546,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('1chuvrlodgphk09bevn0crakv1',1346783254,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('1cl1vbnq6mvsp0dtblo5hdh7q3',1347392863,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('1l7o0j5o43grmd11inmq5ve500',1347381522,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('1l8d10tjfidu8trsmfdajj4rp6',1347481986,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('1m3lrg4cllt57ptchf5a6og4j4',1347392682,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('1rvjdaac717qgrblmbj7etqn06',1347455233,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('1utvrtpasp2s50jkcsjm4m5ev6',1347459287,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('1ve7893hq5rm4s0fv7v2d7drs6',1347558046,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('1vqls9u4nl6548nvoicl0keff0',1347392793,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('21r5h2pp8jn2t6n51ifea9cpg1',1347458338,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('24bidpiq46elpo77otrml07rr1',1346957814,1209600,'flash|a:1:{s:6:\"status\";N;}'),('26c64fba6mqt008hmnssi1bf84',1346349612,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('2fuk4n7hs3q8b0totblet7ks43',1346252817,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('2lfc8oo93d9pnib1p9vepuhqq0',1346251841,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('2m35u9vrfha5q47502ucocobf6',1347387017,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('2menn4ioies6jb3l5oe8rjgo72',1347459171,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('2okhedqii507b8qp4oun7b3ek5',1347557940,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('2sq5hm2j5a585jbrr3h8qt8pb2',1347380350,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('2v3t9bejpd4drmj1l1aij395t4',1347391583,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('2v83rjhaere0tut983adn9fvj2',1346349196,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('31h7e68adu9kd2l4m3fq941q32',1347381164,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('357bbp14rq4ihc9qlq83b490n4',1346349161,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('35t6srn84ql37inv81ltabsjm2',1347459060,1209600,'flash|a:1:{s:6:\"status\";N;}'),('36682261ntvaas4ndnenrdo4d5',1347387984,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('368kf8shsnljgobdl3uf2uk2d0',1346950904,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('36m6upkjqk4fmnvo2ahv0ulvq2',1347457800,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('39b8l2tkf1ha93ch1bomijk7t5',1347558022,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('3anr9eepcj408lsb987vo2c227',1347392773,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('3d6i04koes3fvkg3inieogqng0',1347457816,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('3fat70858qtg03g9kae32t63d7',1346349338,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('3h4edqf774rcb4ssagr482odb0',1347460845,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('3injgkii1633cooj5rrhdbpf71',1347557014,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('3jk2bb08g2eg1pfoqshbg7qqf2',1346786433,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('3pep7t6s9tatogl5ff267oied6',1346786562,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('3qdm60nc92o25htremcajudjr5',1347460614,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('3r15ovn0fubprvn8pbv4c15g72',1347556946,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('3rklvhucqt8epsuvol18kfifs0',1346786077,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('3s9o9iqj2h6k3lbd4vpa022ks4',1347381656,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('409htnpreoogi2f9v7kqhp7hn2',1346786180,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('43g85tge6na8ftqq7pia0ocnv3',1346782616,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('44b3vhgak9kfhdocsgi84nui91',1347387095,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('44dms6ht5lskhs5r44gb7qckn6',1346782781,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('45qh57ediqc9huldlb1pfem7l7',1347380967,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('46jlvprukmj0ai4c56uf1uqep7',1346786644,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('48b95fucei81vvovp1r3tq5i65',1347469774,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('491mnst17m93enemqjr0f3t9f2',1347455139,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('49vstetrckeaagrj1iad2uqnn5',1347391318,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('4b286ag36monnp9milugti9gt2',1347457392,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('4bho04s1sdq68psur42uagj9m7',1347378669,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('4c4ads5nddc5vjr323t3iesj83',1347380470,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('4d8ha91m10lsf75s8edfv9h957',1347460627,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('4f4q783l2iqnt9eqhjl9imc336',1346349295,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('4kbchnm9c7eiffpjp4tgio1q61',1347556809,1209600,'flash|a:1:{s:6:\"status\";N;}'),('4m5mofptn0vpd8km7p50thtcf4',1346348838,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('4p121srq3du3shi76bjffujjp4',1347309923,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('4pnck8r1m82b62k3qut4pa0d65',1347557045,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('4q6e8ski4q7nb2s78ju7s73av7',1347308463,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('4rf0fhid5qhkmk030q96p18b07',1347460393,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('4u1sh6nfkseb65cm8jfneanio3',1346785705,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('508jqg6qcg4kc2ncvmu02g51f6',1346349324,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('55uugcev5j8c7m3oimjuiomuv7',1346790296,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}'),('57moiilqrhsfeh5qk5ij90rqn6',1346251643,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('58lk499ijgv3uti2oplran4n45',1346784755,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('590joagmurqonhs4hlo5n1vqr1',1347309102,1209600,'flash|a:1:{s:6:\"status\";N;}'),('59i4unbbifmnmn23jisf94f933',1347556847,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('5d0o0e4e0d1flg51tja3rqo2m2',1346786343,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('5e94tiurjahjj3947pb72nmqu0',1346349177,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('5gb1hvrlgptij05at0c6nsf3k0',1346961515,1209600,''),('5go8f12c8rrvhboteh6i4ck154',1346785908,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('5hiul7os5uif3km45sf7r67ot5',1346252729,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('5hvamba2csihue7e0571cb9vu1',1347457594,1209600,'flash|a:1:{s:6:\"status\";N;}'),('5i8ur73vrlk0amm9v2fkspuir1',1346786591,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('5mtleatmbvs259ctcnho1clah4',1347386565,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('5nivg43vsd1g8ecggj7gfr2277',1346954133,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('5ojm515865fbt3ltun3uumom41',1347459085,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('5pu4cramthbugegtd314bqbf91',1347380902,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('5t6ignjdni39u2rjikr4rd1s61',1347388847,1209600,'flash|a:1:{s:6:\"status\";N;}'),('5vdm5q21gb78vvrs7537o7abo0',1346350495,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('60atv8celno9e035i8mu7kas54',1347558027,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('61m5lsphm8shmsqh2l7llv6kl6',1347460807,1209600,'flash|a:1:{s:6:\"status\";N;}'),('63q1808mi9fnkah2hhbfe60t85',1346357517,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('644gm3g1fc73usvvugih5rs1l0',1346785763,1209600,'flash|a:1:{s:6:\"status\";N;}'),('64m1q1clkpjbjl095377ur8ha1',1347392046,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('65ateleduvcl1u5asopl0je4u7',1347391702,1209600,'flash|a:1:{s:6:\"status\";N;}'),('65d13l1hhj2r36dctaak4121o5',1346786261,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('662an4v2i6stbl839m9stis9a5',1346252028,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('67e055sia0o49j5clnfii25ka6',1347308663,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('69kd5abqb8na9e95snh41kjnq1',1346786167,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('6h8568kk2koentu1452co0smj7',1347389047,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('6iipagclf4fgh3spn3lsj6jko3',1346252421,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('6mkab9olnuq4hebc2ua0hmm531',1347391306,1209600,'flash|a:1:{s:6:\"status\";N;}'),('6r8ff5dvl84uvrphc6856mnnd7',1346252207,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('6vkeblunll0p34sl8iuvgpvel1',1346252576,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('70f8f7u8g0j7f5nolqc9k5iuu5',1346252772,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('72reti32f09fo2ta4dduub0sf2',1347457335,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('74k6i1qvrn2ddm8is5n8sunlm6',1346785804,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('75bo8lcjjg39thukn4kq994131',1347381103,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('77jv4vkl80usm6bkkjgt0ar5r5',1346783414,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('78bvmduolv81jkd3b6nech45i6',1347391484,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('7aa6ghavd2ema5e0j44dst9ku1',1346786324,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('7epe9msd34gq17jq9eshpauib4',1347459346,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('7kmmbcmtuvimbqvaua5g4e7kl7',1347388944,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('7ngveehrlkmnumtjep37ade9b0',1347378958,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('7qlrrpbjkjk5uqjeh7r5nj68n1',1347309717,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('7u7m4citqhcaqpmf4f82mo01d4',1346952594,1209600,''),('7u8n8sap6m6pluqvn5ogm0tm53',1346785999,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('82a20imrudugtsa66mfv457c34',1347457489,1209600,'flash|a:1:{s:6:\"status\";N;}'),('83iblae7ttqlv82nglf30bsr85',1346792175,1209600,'Default|a:1:{s:8:\"redirect\";s:19:\"//admin/users/login\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}flash|a:1:{s:6:\"status\";N;}'),('84492cm5c8v9rl78275tj1l2i7',1347465467,1209600,'flash|a:1:{s:6:\"status\";N;}'),('84dja2ocnd4eih3rn5cqqsih54',1346251915,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('88bqvgdbg15qcb1cek929q4i92',1347468169,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('8bed9bdcuevs67e6ss5n5cdrn0',1346786585,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('8ck12ou66kfq2ibp4b0aaorjd0',1346783272,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('8hdum6httqa5t2kv56da3h5qo1',1347481958,1209600,''),('8lrql2pb5kqm4p2lsve4fp3230',1346357508,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('8oqdq8m390omrmqelpi59722p4',1347308505,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('8rk7io0ho2rrd83gau70elk6m7',1347389029,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('8vk1f4knjvqg0vv7a59ofn4li7',1346349560,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('922rbvle1nj2oq56vaivtnb1d0',1347460501,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('92fvhg6nqgd4gbk5qai6irvak5',1347459380,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('96ubpl7iiheb1fb1mjff7hqlr5',1347457351,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('970s8n237tc4o299ejml2uvtt1',1346251734,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('974gvmvguvtl3skdv1cb92gao5',1347380838,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('98qouak9btlpfipc4v9772s3d0',1347457326,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('997seh6sjjle8ga6a1ji4iiu07',1347458221,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('9a9ps307fhmjdves0ddt00o7i0',1346252569,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('9g6cl73i02dq9v9b589dhojep0',1347459441,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('9h7i4vbrp55si580517tr82c85',1347455321,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('9hkub4pfu75vunqucqemntamm2',1346349045,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('9hsjpbulm6hp755b4ijfpe4p82',1346256014,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('9ns25ok5f5ih1dljoctpjd11d0',1346349586,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('9t750scv1c24lc03g3gjkebhe0',1346252321,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('9ta81buadkk73ntmssrs0kg5e6',1347381800,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('9tc2dpi33gh30r08dogvodba46',1347460520,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('9vqqq1u18h5ndc25tkhvva9p77',1347380412,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('a1v9te64pk32b0elo9t2fauve7',1347386580,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('a2skamo6mtecc1g0b1mtk7jcn4',1347386996,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('a3cd4kiqbvr7456lg0q7efse72',1347457397,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('af55innhgef74cnlo3usn6vh55',1347392836,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('aff2asd6n4chj8jba9f19h3fb3',1347457834,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('aflq95325orckd5n46esgk4p11',1347464846,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ag45062kiba8jfdno4d53t7vv4',1347556756,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ain1m16a0ie0vgq6lsgpa81nt0',1347309433,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('aj45qlpunlfvqlp5rjvpa1q167',1347392806,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('at05vup6afmreai5seae9cvtv2',1346248915,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('atm898p9u5td4q6r0a982274a3',1347457695,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('aujh35m56snugb68id8lsmdrr3',1347457680,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('aun8hifg7afiad1u2gb5djvsv3',1347455051,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('b0gqta6nq2nnp2pcmrbgttrks3',1347459268,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('b1ns95qrvtfd7h60i1qsmkq1m4',1346783820,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('b44aasknhitr8rg5ju4ioqjqm2',1346783279,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('b4od1s5f0p0gamq287c3lhtsp5',1347556928,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('b5ptsp2f46mve8vn0ov4g0qnu0',1346348964,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('b61m3hcbodpiluebqh7k0v12l0',1346957747,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('b9be9prlg4u50g9afe7apl5q72',1347381730,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('b9e0c9u8tvhj6kqvumjab004g1',1346258091,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('b9fibouq968csrp7ko9u7eipq2',1346252230,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('b9jpnuvvgt4iarel4vufe69ll4',1346349594,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('b9tl1emra8t4dahen8f3ch5sl5',1347457893,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('bahg8d8uui0levgu36le7ng8e2',1347457381,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('bakbms60ihh57gk93vupfkhbc1',1346348872,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('baoa2bvbojoupu9ghegm85c346',1347457412,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('bbkmauedh9ghnc1higfuv3vbg3',1347556951,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('bcefgblqi70hc3krkeqd03vt00',1346351988,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('bj1t0vtftv72iivq96lr054jg4',1347386749,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('bjgcitgn6g4ncrv1hmo1mp4ki3',1347380782,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('bk42kji74hc0ijju4n796ona37',1346786610,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('boferpf7e9j1kii74e7kvrvs43',1346783899,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('c30p1rqre0ktjtouphaer14mj2',1346783926,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('c3t8aaj821a1aqhaju36l71lv0',1346952294,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('c6h3mb8rgq3jliuelsinf8dr46',1346792089,1209600,'Default|a:1:{s:8:\"redirect\";s:19:\"//admin/users/login\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}flash|a:1:{s:6:\"status\";N;}'),('c7j7bc0287ar7lit48c1u731f1',1346786355,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('c7n6h9v0mic2tr28p7cu6tbtc6',1346786153,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('c82irkg0vkvvsbj4d6huk6q1o0',1347391754,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('cbkm3t4km5vrl40fvsa28nk0b2',1347381407,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('cd4fkvss5f1ta4deg5mv4opi97',1347392780,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('cd6p2stoian0viqoh8dv1kr4t6',1346349571,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('cdia9hvdt536be8j9dv5f6tp20',1347378732,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ceoga5758hhi1mvgb30q8342o0',1347455251,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ceu0kbfe0nfgq3bm3kudhn6od7',1347309585,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('cmmqj0p7t78hk7l16l48t5k193',1346252249,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('cnf8ok5r046fcrgekgmacltjm0',1347308444,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('crnde4pl716jl25g31e9iofha1',1347381036,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('crtc9kfjvfg2o9iql6heho8lb4',1347458297,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ct0ag1ra5c20i17rrib4mc1eg6',1347558034,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ctpu2mba04dfem3q396cedlvs3',1347457671,1209600,'flash|a:1:{s:6:\"status\";N;}'),('d0io45ljcatu603a3dmh6vded7',1346251957,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('d44csndmfmhk9sn9vlcpl1g0q1',1346952277,1209600,'flash|a:1:{s:6:\"status\";N;}'),('d49j9cp3dhqf6okln2qhpgvse6',1347381858,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('d5metf41run59abj8506tghf54',1346349034,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('d6mvkv23sgts7oi4g6pc1ktrg6',1347380719,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('d90h3qlo1gkk7pb4qf0hakfk40',1346252837,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('dabgjjkgct7mje668c4tde7jn4',1346792079,1209600,'Default|a:1:{s:8:\"redirect\";s:19:\"//admin/users/login\";}flash|a:1:{s:6:\"status\";N;}'),('dalt6r89bel0lao2030re1k0v1',1347390458,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ddda7u4haritigvqrf1ikqgj57',1346782546,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ddfucba2stp29ju9j0647ap2d3',1346348936,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('dgsagtqhhb6rs4sqk45una03a2',1347558127,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('dgvsko7aqff88asfmeeh2nm7d2',1346783345,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('di7ce76fk2cfvun4bhf9peh0a5',1347308567,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('dibtnto83atlbmqluvjnt8fph3',1346961335,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('diq002fvaj92n3i4av1h7ur350',1347457956,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('dj0hlg0pcmjtkbgicrft1shee3',1346252483,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('djc4icefs5lna004irtt86m030',1347455312,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('dm1bkbvnaovt0fke43p033skj4',1347460673,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('dn1h5msuddgctfcq1qliop1mo0',1347381920,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('dnob0d5978t08fsmrfbb9l4cr1',1347391827,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('dqheqeq4vcgi3lod6ml1gga2q4',1347381583,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ds6nu7aushuolmq6od2s0nju45',1347380596,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('dtr8pt64oq4c7ec6sq749m5k66',1346349678,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('dvvsnhcbs835p0fr66fjrajmm0',1346783117,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('e1t2qmf9vf89r1t0dmajvdgqg3',1346785766,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('e2ng3qh11eo6gda8d4emsa04k2',1346789805,1209600,''),('e4m4gpoef6c8kmsblotgf3u1c4',1346252449,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('e5br55kgdgkrlu1r0vdl3vkhr5',1346350679,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('e6glovilk8a0u4j4ciu6okp223',1346942431,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('e99nh016mpktrfrdm7a5a5egu2',1346783038,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('e9qgtn1iq86b6r9ler2d3ar5u6',1346349365,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ebbski01iaaobibop79rn5j9u7',1346251781,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ec1p2rg23rvmh7sdnenrogke20',1346348722,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ecr3o2c61eb9m2doo1u5mhuvt4',1347556913,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('edknqdkjdi4dd3qkhq3qrelm52',1347391723,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('edl8flp3cvmvkuvmevhha5d652',1346786429,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('eetq1901tpqokihaek5lvmtlr1',1346783886,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ehdikfi9866ti0gp2k9d6hick7',1346791761,1209600,''),('eksk1a0iqjbu5ibo13de16dvp2',1346791772,1209600,'Default|a:1:{s:8:\"redirect\";s:19:\"//admin/users/login\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}flash|a:1:{s:6:\"status\";N;}'),('em0047emedbr8ob5duecusfc52',1347468163,1209600,'flash|a:1:{s:6:\"status\";N;}'),('em0lt0hvi26l619gud8tjp0e92',1347392528,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('emu7go10o0tuns8qesogh97817',1347385661,1209600,'flash|a:1:{s:6:\"status\";N;}'),('envg3n795pa2mljaq282gqvms2',1347392058,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('eojnesi2velrqselj65jumv942',1347459070,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('evi4h5faqh0untm5k4eok0htv2',1346784401,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('f111all7m450hcdfpfbn2dlvt0',1346252368,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('f1d3j4d5gb8fqsq13e2252pm12',1346789810,1209600,''),('f330t359qpqseme09n1i0srnr0',1347457710,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('f3el8dln690b184viikoh8m7j2',1346954587,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('f3rueqdugot6fafqbdtu3u9ik6',1347308690,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('f94fk8vtsc1rogr0f8v1v3ai93',1347308637,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('fa4rno11u59h9p5da9t7q1rk33',1346786674,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('fac23426iecilai2emlheojil7',1346786244,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('fclog7cc8e8eb8rt7hn9mr2jj5',1347388260,1209600,'flash|a:1:{s:6:\"status\";N;}'),('fe922eu85ulueshb5uup0h4ob3',1347557926,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ffdv4e4gsnkfps30njpmevl7v5',1346352039,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('flljjp6i9iicb22iv5hntusaf0',1346351410,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('fnjmohgsf6vl8rh1ackpveij37',1346252394,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('foehf5o2e74afp807eiuu49847',1347388865,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('fp2l23t0pol9vr24m1mmkl05f4',1347390466,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('fpi0s4bt4orgntcfl7corhe1l3',1347557907,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('fpqjstfiv39r8iqj5n89n269e0',1347377761,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('g0e677l2quv1tgevujen96rrm7',1346954565,1209600,''),('g1qsisur1jclvpcfa8a362muk7',1346961521,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('g22lo64l49k78oa86bslb5d474',1347386905,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('g2evnnls4g42j3gjdvv4878ie4',1347455016,1209600,'flash|a:1:{s:6:\"status\";N;}'),('g48q7tph92phe3skaurl5ej1f1',1346953049,1209600,''),('g642b5s1uu72o5t9jf4tuffbn3',1346783548,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('g6i04m0kb9i1vnftk6vnms8tk5',1347556968,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('g7pihl5fhmjrjrosub1ammlqn3',1346349310,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ga015c4fdmpp7td936p86igmj1',1346252274,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ge18d6g9ud1a0hs0c0ojkneg64',1346349122,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('gfibshd771amdl266b19fpti41',1347455217,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ggq0ouinqlt6ngfqn62i1imqn2',1347465394,1209600,'flash|a:1:{s:6:\"status\";N;}'),('gm787v694d7kaps0vd3psvuh42',1346349229,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('gn1u8klhtt62a350vvp4bd3rl5',1346785840,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('gobsicdft1vjvst669ntr5ppp7',1347391332,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('gplm88m4up34t76u8kp9kpe872',1346349214,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('gq5c5sedcg40btef6jo3pj7vq0',1347455346,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('gqkf8e8l5v2i2annfckadta6i6',1347380654,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('guo6hmqdsjfo6locsj6t3gvn94',1347381041,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('gvmsm8hvlnh9k8cr5j1tpf4vq1',1346951290,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('h1tuuj2lbk1s3pagv34jrvee11',1346782425,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('h452cm5ft7ii0o3r52hsj4mqo1',1347309656,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('h53rgphml0t7nmtmo6fcj71k75',1346961320,1209600,'flash|a:1:{s:6:\"status\";N;}'),('h6qh0bev6hka722qe9tq3s7e74',1346784149,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('h9383bt99pcauhurui42mg67h7',1347381349,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('hbci1pab71knh48ufv6f1bp7r2',1346783920,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('hefg2tp6lud4gpgnuissjb82e1',1347458281,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('hhqjvt01b1lt6rdges1rnfd941',1346252387,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('hlghu58vndb8khtgaeo9fvbtp2',1347557000,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('hm6t4nu76nvmepcdofdglq1b42',1346786300,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('hno3qo46cddpr37nonnl5fomn3',1346951459,1209600,'flash|a:1:{s:6:\"status\";N;}'),('ht7s1579pd01q10hg9m3sk9nt2',1347458063,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('i00pqdnmoqnb492tdbc8rtni56',1347460545,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('i1f5io9rspv62m4p25a29a84k0',1346957820,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('i24dptc29qa2ap4ipbb773mu43',1347391922,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('i6tf6on21ngtectvofs7o7kc83',1347309913,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('i9onvmctm63ik1uo5jhtis8vt2',1347457358,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ibcd92kcs6ernmlnrfibhja752',1347388797,1209600,'flash|a:1:{s:6:\"status\";N;}'),('ic08ncl53149slgfau4lcu0c17',1347392612,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('iebouq24dmovh6t5jqcas8oi02',1346944408,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('iepv7dv7ahhtsibhh5krkgvfd7',1347455359,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('igjmovj8a95b87b1q00iiq7hj5',1347458325,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('iin7hh6p3htem86a8ehm8f1mf7',1347465426,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('im1me0bqle3lom3hr58pq6hs12',1347378838,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('in6kqbgm7vd7c0tnl5t07h2v42',1347389242,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('it0g34qst4ajg9h7e593tbhtq1',1347391982,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('it5tdm6rv3av0dva1ns5rurjt3',1346951477,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('j3mp0b2k9q3divmvbl0p6naq04',1347459153,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('j4sc6gnosn8c32k7toa9cfnbo0',1347457617,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('j53nl1n50chbci8jgvvm2vkga5',1346785926,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('j5eiii067kvemq3mpcrhr1a9n0',1347460817,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('jc4aspfira3480julvsdi4jfe7',1347469741,1209600,'flash|a:1:{s:6:\"status\";N;}'),('jeth89eov8i8bdhc6j6dds86a2',1347308496,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('jgb8qf7459emptl9m9n01agin6',1346782771,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('jgkkvbjhr804pp8m0dq0nljeq6',1347392085,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('jh2591b8voalsghm52b7ck10r2',1347455123,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('jhbbe17l9fgutbukbj43jkvl96',1346786571,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('jhig3fujd0ndt68f6t3mojcl21',1346783682,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('jjffg3qce09mk7hodpcuardaj0',1346349443,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('jnn516ill7uur3dmaa0j6b90o7',1346783263,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('jobfv1d8m7nsustmpg9kess5d1',1346252710,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('jqhcqbn75mcj5hb70ccd8m14p0',1347459365,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('jsf2ln2voh4urbjqtbrtcge0n6',1346351987,1209600,'flash|a:1:{s:6:\"status\";N;}'),('ju46n6l92ongo69eiber3mib23',1346786277,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ju9obada81fdkbqi1a8504p3n3',1347392514,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('juirqksa209c08s7rogka470r7',1347558094,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('jujqq5akvqs9h200g7p3ah6pb3',1346349353,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('jv05hgpbt4ktaut3011dhiloo2',1347459399,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('jv3hn3m6h8o6rgcav20dhi87e1',1347392820,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('k0oo39k2m6qj7m8cea8q9gad33',1346785782,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('k1ftmie0gr8715kamrtbkct651',1346352038,1209600,'flash|a:1:{s:6:\"status\";N;}'),('k27pi3ku3s000ti17s8brr9d72',1346785696,1209600,'flash|a:1:{s:6:\"status\";N;}'),('k4bp7or6q5qaljcv0ecuu7jj34',1347379028,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('k66fu0cqeev7vd78aud7bshtf5',1347388958,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('k6m3qml4q7k9rmkgqjq8kbreq5',1347381032,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('k9rh649a14fvuh30i7q1r9ngq3',1346252871,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('kdnam609qrp5mg1paggthtsfg3',1346951269,1209600,'flash|a:1:{s:6:\"status\";N;}'),('kfa4r5lgt2pp2tntbrfulkpls3',1347458367,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('kh6lr0m0kpffvjd9dmpdrfr6m2',1347457489,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('kmesqp102gleapkcq4vc15u9i5',1346349143,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ko8v99f6nvjvllrccj275280b7',1346790372,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}'),('ksl4fvftnf1rft6t2b17o6l1m3',1347557755,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}flash|a:1:{s:6:\"status\";N;}'),('kuaskcghd5nag6c812amrhvpk6',1347458185,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('l0uh0adhji6fub4cioqt1060o5',1346942411,1209600,''),('l1ebk7n6q1iquoob2a1uml6fe5',1347460480,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('l36bkii605fjep75m5ece95tp6',1346251759,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('l50d082nn1m4k0o64abk42g2l2',1346252345,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('l5v7ct52n28d1t3jmdgsm3t6c3',1346252751,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('l9qckdrq0prssqo7tk1g92svl6',1346961754,1209600,'Default|a:1:{s:8:\"redirect\";s:13:\"/items/browse\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}flash|a:1:{s:6:\"status\";N;}'),('la1hvbf9p5lmej7ob4mh5b4pr0',1346782956,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('lec4ckiq1m1ga90bdgi2rn1v22',1347457419,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('lfl2r9rvbn1hp5lkgdh3k8n407',1346349627,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('los4e81fru5iqamdm6c3iqpcs3',1347457369,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('lpj12p2a42qrpko02jkt4nss33',1346785932,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('lrltdlslscv3qlvejdps4rqqd7',1347458054,1209600,'flash|a:1:{s:6:\"status\";N;}'),('lvn9svnq8e338jhqck1nc0ntg1',1346786195,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('m0ocs4gu43msuhjmq4ivt4s212',1347389061,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('m63i27vr6h1atlp9ubrn9jou00',1347387966,1209600,'flash|a:1:{s:6:\"status\";N;}'),('m6l0u3eke0rlclmr3djlqghmn4',1346786292,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('m8lagntgf7sn9s7n8lr406pf97',1347385221,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('mo0ipoqebeadj9plqn4kv8qfn1',1346252800,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('mpli6oakqgkjjcar0i8ll4nhp4',1346783914,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('mqkvdnjthu78h5jq5pfns7o3h4',1347457912,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('muu9o76cjp48nhft7doaqcggt4',1346350483,1209600,''),('mv06b1tt200trunks5s6tsdnj3',1347386842,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('n0j3mg36jp5p60n3ppatv5iai7',1347458110,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('n0kmn4fkqg2pm7lofv56jsk4p5',1347556957,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('n0sprdfij01ag4p93bjm7cad53',1346786308,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('n72pbo4js1rbqng9fqg9p6tl03',1346348779,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('nao82oth2vmmrg2ig5sj0es326',1347389119,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('nb67ihoprpodphe86pkufs8k51',1346349250,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ncnscnlo746odph20mg4c2aap4',1347458287,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('neo3er7frr0m9at2ko1jn4p5o3',1346252431,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ni78bdfm63br0ntkvi45rtaka2',1347386768,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('njo7tgjuk5k47dq91k8nbthh37',1347391378,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('nkbpetb8i29mptiiuvchlg0ho6',1346792164,1209600,''),('ns16pvrii399fjt1rdonvq2p17',1347556830,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ntcbjtpv30b5g4ub4osmc47s65',1347460607,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('nvv0nfesi5jqifsuucgder4fg7',1347457602,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('o9tc9h8oaicpfqulp6d1muvt04',1347387026,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('oet89e1ika8dsmmcqi4h5cqhj7',1347457927,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('oetjd6hjndvr5f4c2qq6j3mfn1',1347309845,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('og4nr4grvatiamid4br75243g4',1346252122,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('oiqao8tie7rldjgispqiod6is1',1347460461,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ojur7os20902l8v90ljt1iiin2',1347378805,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('okh0dmhscd113951nlru3u8960',1346953071,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ol12kdg98ihprpv2lfthfe5cd5',1347460704,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ol586r84r2gs13hjvipj83stg2',1346252041,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('on6rfrp962s5sfcedjcqn0cf23',1347464780,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('op949udpnehce4o24ckmcfhh75',1346790587,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}flash|a:1:{s:6:\"status\";N;}'),('osvrdl54eg0e1lg1fisla6tv71',1347457983,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ou366sa4d4a9hco33jt2sa3940',1347381593,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('p0e2qhbr9tnhrnuglhg50kvr22',1347460367,1209600,'flash|a:1:{s:6:\"status\";N;}'),('p0kvcnlrd6ag2cm743tm3ndet0',1347464789,1209600,'flash|a:1:{s:6:\"status\";N;}'),('p5gt5vl17kpq3r63tj1krns970',1347385675,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('p7s1l95eo6c3dpdgomgmd43lm3',1347457296,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('panvlmfm1sdqec9v7ug5mosik7',1347558060,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('pc276346friebm05a1svt2lgj6',1346783751,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('pffbnrb69eoghrtp6cl1mtgqv6',1346349305,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('pg49uulugv00c6rnoiac04idj4',1346783907,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('pi2b8diu6uuhd24b7g9pl5h105',1346252301,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('pkm3npk8d9o2vovdu25dp2bjm3',1347558001,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('pmn1r68lluc6mbaav3d0nomi57',1346252406,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('pni7srca45am37b90bguok6a56',1346946130,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('pto38eq634fed46mejj84ahk12',1347390553,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('pvir626731g0a5mj89pijkocg3',1347380533,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('q2sk4sce7nojh13iprvjgscf64',1347460798,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('q5b064brjif4i2qeu4i8gu7j07',1347457364,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('q76cv3nndrnbauklo0psffs6n7',1347458199,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('qb03lidueub4ai2kgfn02tfdr4',1347390530,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('qb11dmqu6rhoef2q4e65gdq973',1346351769,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('qbat7h5kokaauq4sroadrfebr3',1346786622,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('qbi3tpao1dstn1cqr84mct3cb3',1346786210,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('qed1t4ef65768lksl2kdkuslv3',1347381024,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('qgdfc87lbbvb03g084mejl3uc5',1346946112,1209600,''),('qgjalv978akjidni5q92rs7cs2',1346786227,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('qn6quq1o1hs0ftb6bkf2ejd040',1347464814,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('qn7aij2apt5fkj7hth0efeg162',1347386655,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('qp2itign5eq7dpeq2isq48mmo1',1346786006,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('qulb7qm0c4gi8s8r1782n20ee4',1347391567,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('r1hekh9dqe121otadet994bda7',1347457727,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('r3q51o7s7ko0l5sum1iaklidg7',1346348971,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('r7rvih4c7ug3q5ia1e4k7flkm0',1346790560,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}'),('r9u8j9vlg4n47cu40psoi6ebp1',1347460659,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ra687m6t1qt49lf2ka9e6io1e0',1346252468,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('rakdmlfasv7nad1kolaeipg9m2',1347309777,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ran09imkj1smkirkbb1fl6j0s7',1346251942,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('rd6egl745i1lfc288jmrr1kkh1',1347309365,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('rj3mgiq6dj826mt899ipudr4u1',1347392714,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('rq4gu2snr4i8qoj12oep7msr44',1347457302,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('rqmpbl2lltjq9tigdlrjq36te6',1347392697,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('rs9k38cct5g8stoqe1u7ebli50',1347455400,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('rumjn3kis9f75t3ajejdmffep4',1347381290,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('s1q0um9cf8m8j1njlr5cr0uii4',1346952610,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('s8r3gj9ltvomepb378cejch820',1346782476,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('s9k8951ro5iam4r228orc08nn4',1347308480,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('s9o2gf374feijbvps3i0lrjm80',1347455374,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('sas9r3gbstorv5j3u05mkl16l0',1346786287,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('schriltqqlvvo7q2gpjdmepmh3',1347385215,1209600,''),('sd8l48bml70lr1ltph6g873852',1346350669,1209600,'flash|a:1:{s:6:\"status\";N;}'),('se4scs0pl513d9nqu5c4s2rd46',1347386782,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('sgkipkfp9o8boaufeg2jlm9l93',1347459250,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('shetrjeq5rr092ei4o2iqvgml4',1347455038,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('sjfeeiivtuivcrsssdle5o3si6',1347391843,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('skhn00qe32hndtdsejr60o50m7',1347391473,1209600,'flash|a:1:{s:6:\"status\";N;}'),('sp776qpr3cccj72uhl5hhu9lt0',1347460640,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('spf4opsrs46parbdmo6jdnge40',1347458078,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ssa3naulvgcjttf5qu1rih85i0',1347389178,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('t1ggp1bckpe9shhburrq6i7rp7',1346349272,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('t3omc4kcncr642us81dea0lsp4',1346786272,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('t9b7a1nmfvg1eml5jl59dk4qc3',1346357070,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}flash|a:1:{s:6:\"status\";N;}'),('ta69dchlhc876nn5tv8nobcqt5',1347378899,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('tanljjj735b5olohhqsal003l4',1347465498,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('thmvp70b95c85rrlip08svd840',1347391559,1209600,'flash|a:1:{s:6:\"status\";N;}'),('tl1inmo00bhkll31e8jmm0l6m0',1346255783,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('tm0hdfv6fe1uab7vk6nlol63m4',1346783616,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('tnd2fv93ct74cu7cl6ivs96i95',1346785527,1209600,'flash|a:1:{s:6:\"status\";N;}'),('tqb4oeiju2fgrk95fcn0e4j9q7',1347392111,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('tt1lvce2k5mb8noofmabcvo885',1347309299,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('u41f07sno48j7rc2orgtuaqh22',1346348812,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('u4jlbkvugv46phbluksgfuujn2',1346252413,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('u56h6focrn8nkg811ll5ceuec0',1347460376,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('u57rlasfmbauf2fqsakjvjl6j2',1347308647,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('u6u25d05qoksasgnkc065pmb32',1347557960,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('u6v642330f7k7es1pgqsp36h11',1346349290,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('u8pjr7dbvntka1tu1attmgmqp0',1347455334,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ued4iniefmdimkpjmv74k1cv70',1346782918,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ufi16phps7h7tcjg74n6o6b5t4',1346783481,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('uidmo0g4674l79gjahonn8g3f1',1347556981,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('us4bi1bdt00mpndft077q8cgi0',1346789880,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}'),('ut0clqubad80k97tbj736guvh5',1347378658,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('uuivf6184os2gj702fes19akm7',1347387122,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('v15nk1gkake7a5lma2591n04b1',1346357477,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('v2d0ivd781kc1uept0jsn2qjg1',1347556862,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('v5opkvpovlb23od0ov2ggdg893',1347386671,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('v80mg39qmbcjv61psb03ldous2',1347458308,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('v8d13crcbfulsto4k9fg0q7ab1',1347392071,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('v8qgi3vkvqrv9e4orc7fh9ju21',1347392596,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('v91dm6lopfoft346ajdo92p770',1346944388,1209600,'flash|a:1:{s:6:\"status\";N;}'),('vc473depbc5rt0kmkphjiulpp6',1346785530,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('vdfi2onbm6o9poh6mjd6515m57',1346957737,1209600,'flash|a:1:{s:6:\"status\";N;}'),('ve5irekv78m0avk5f4vsnarq31',1347391709,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('vfm5hcqv3aje4v0g9o7a0tucq2',1347457943,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('vi1548m5n6rslrum8tmjs1b4i4',1347391739,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('vk6qta5oj50t5opk4ftcv0fie6',1346350507,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('vlf0j0108fdapcubf1prc3u680',1346782688,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('vlmn68eq5d57s5hiltu9r596u2',1347309939,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('vm60qpthcmh1e56l8pf4vci5m1',1347388854,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('vnfsm0d84tais6s496vd7s8e16',1347381227,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('vng60nhgpj2ui28dd26judp6r0',1346782847,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('vqtqpd4g58a6sp00b40nr6h336',1346783992,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('vv2j5op08sjp81ouj0r2hgsnk2',1347388811,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}');
/*!40000 ALTER TABLE `omeka_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_taggings`
--

DROP TABLE IF EXISTS `omeka_taggings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_taggings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `relation_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  `entity_id` int(10) unsigned NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag` (`relation_id`,`tag_id`,`entity_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_taggings`
--

LOCK TABLES `omeka_taggings` WRITE;
/*!40000 ALTER TABLE `omeka_taggings` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_taggings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_tags`
--

DROP TABLE IF EXISTS `omeka_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_tags`
--

LOCK TABLES `omeka_tags` WRITE;
/*!40000 ALTER TABLE `omeka_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_users`
--

DROP TABLE IF EXISTS `omeka_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `role` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `entity_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `active_idx` (`active`),
  KEY `entity_id` (`entity_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_users`
--

LOCK TABLES `omeka_users` WRITE;
/*!40000 ALTER TABLE `omeka_users` DISABLE KEYS */;
INSERT INTO `omeka_users` VALUES (1,'neatline','4ba1778d5485a39685721de7bf18e79cbedde574','6e2567ece63d017d',1,'super',1);
/*!40000 ALTER TABLE `omeka_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_users_activations`
--

DROP TABLE IF EXISTS `omeka_users_activations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_users_activations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_users_activations`
--

LOCK TABLES `omeka_users_activations` WRITE;
/*!40000 ALTER TABLE `omeka_users_activations` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_users_activations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-09-13 20:00:47
