-- MySQL dump 10.13  Distrib 5.1.63, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: omeka
-- ------------------------------------------------------
-- Server version	5.1.63-0ubuntu0.10.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `omeka_collections`
--

DROP TABLE IF EXISTS `omeka_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_collections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `collectors` text COLLATE utf8_unicode_ci,
  `public` tinyint(4) NOT NULL,
  `featured` tinyint(4) NOT NULL,
  `added` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `public` (`public`),
  KEY `featured` (`featured`),
  KEY `owner_id` (`owner_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_collections`
--

LOCK TABLES `omeka_collections` WRITE;
/*!40000 ALTER TABLE `omeka_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_data_types`
--

DROP TABLE IF EXISTS `omeka_data_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_data_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_data_types`
--

LOCK TABLES `omeka_data_types` WRITE;
/*!40000 ALTER TABLE `omeka_data_types` DISABLE KEYS */;
INSERT INTO `omeka_data_types` VALUES (1,'Text','A long, typically multi-line text string. Up to 65535 characters.'),(2,'Tiny Text','A short, typically one-line text string. Up to 255 characters.'),(3,'Date Range','A date range, begin to end. In format yyyy-mm-dd yyyy-mm-dd.'),(4,'Integer','Set of numbers consisting of the natural numbers including 0 (0, 1, 2, 3, ...) and their negatives (0, âˆ’1, âˆ’2, âˆ’3, ...).'),(9,'Date','A date in format yyyy-mm-dd'),(10,'Date Time','A date and time combination in the format: yyyy-mm-dd hh:mm:ss');
/*!40000 ALTER TABLE `omeka_data_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_element_sets`
--

DROP TABLE IF EXISTS `omeka_element_sets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_element_sets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `record_type_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `record_type_id` (`record_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_element_sets`
--

LOCK TABLES `omeka_element_sets` WRITE;
/*!40000 ALTER TABLE `omeka_element_sets` DISABLE KEYS */;
INSERT INTO `omeka_element_sets` VALUES (1,1,'Dublin Core','The Dublin Core metadata element set. These elements are common to all Omeka resources, including items, files, collections, exhibits, and entities. See http://dublincore.org/documents/dces/.'),(3,2,'Item Type Metadata','The item type metadata element set, consisting of all item type elements bundled with Omeka and all item type elements created by an administrator.'),(4,3,'Omeka Legacy File','The metadata element set that, in addition to the Dublin Core element set, was included in the `files` table in previous versions of Omeka. These elements are common to all Omeka files. This set may be deprecated in future versions.'),(5,3,'Omeka Image File','The metadata element set that was included in the `files_images` table in previous versions of Omeka. These elements are common to all image files.'),(6,3,'Omeka Video File','The metadata element set that was included in the `files_videos` table in previous versions of Omeka. These elements are common to all video files.');
/*!40000 ALTER TABLE `omeka_element_sets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_element_texts`
--

DROP TABLE IF EXISTS `omeka_element_texts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_element_texts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `record_id` int(10) unsigned NOT NULL,
  `record_type_id` int(10) unsigned NOT NULL,
  `element_id` int(10) unsigned NOT NULL,
  `html` tinyint(4) NOT NULL,
  `text` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `record_id` (`record_id`),
  KEY `record_type_id` (`record_type_id`),
  KEY `element_id` (`element_id`),
  FULLTEXT KEY `text` (`text`)
) ENGINE=MyISAM AUTO_INCREMENT=232 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_element_texts`
--

LOCK TABLES `omeka_element_texts` WRITE;
/*!40000 ALTER TABLE `omeka_element_texts` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_element_texts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_elements`
--

DROP TABLE IF EXISTS `omeka_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_elements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `record_type_id` int(10) unsigned NOT NULL,
  `data_type_id` int(10) unsigned NOT NULL,
  `element_set_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_element_set_id` (`element_set_id`,`name`),
  UNIQUE KEY `order_element_set_id` (`element_set_id`,`order`),
  KEY `record_type_id` (`record_type_id`),
  KEY `data_type_id` (`data_type_id`),
  KEY `element_set_id` (`element_set_id`)
) ENGINE=MyISAM AUTO_INCREMENT=86 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_elements`
--

LOCK TABLES `omeka_elements` WRITE;
/*!40000 ALTER TABLE `omeka_elements` DISABLE KEYS */;
INSERT INTO `omeka_elements` VALUES (1,2,1,3,NULL,'Text','Any textual data included in the document.'),(2,2,2,3,NULL,'Interviewer','The person(s) performing the interview.'),(3,2,2,3,NULL,'Interviewee','The person(s) being interviewed.'),(4,2,2,3,NULL,'Location','The location of the interview.'),(5,2,1,3,NULL,'Transcription','Any written text transcribed from a sound.'),(6,2,2,3,NULL,'Local URL','The URL of the local directory containing all assets of the website.'),(7,2,2,3,NULL,'Original Format','If the image is of an object, state the type of object, such as painting, sculpture, paper, photo, and additional data'),(10,2,2,3,NULL,'Physical Dimensions','The actual physical size of the original image.'),(11,2,2,3,NULL,'Duration','Length of time involved (seconds, minutes, hours, days, class periods, etc.)'),(12,2,2,3,NULL,'Compression','Type/rate of compression for moving image file (i.e. MPEG-4)'),(13,2,2,3,NULL,'Producer','Name (or names) of the person who produced the video.'),(14,2,2,3,NULL,'Director','Name (or names) of the person who produced the video.'),(15,2,2,3,NULL,'Bit Rate/Frequency','Rate at which bits are transferred (i.e. 96 kbit/s would be FM quality audio)'),(16,2,2,3,NULL,'Time Summary','A summary of an interview given for different time stamps throughout the interview'),(17,2,1,3,NULL,'Email Body','The main body of the email, including all replied and forwarded text and headers.'),(18,2,2,3,NULL,'Subject Line','The content of the subject line of the email.'),(19,2,2,3,NULL,'From','The name and email address of the person sending the email.'),(20,2,2,3,NULL,'To','The name(s) and email address(es) of the person to whom the email was sent.'),(21,2,2,3,NULL,'CC','The name(s) and email address(es) of the person to whom the email was carbon copied.'),(22,2,2,3,NULL,'BCC','The name(s) and email address(es) of the person to whom the email was blind carbon copied.'),(23,2,2,3,NULL,'Number of Attachments','The number of attachments to the email.'),(24,2,1,3,NULL,'Standards',''),(25,2,1,3,NULL,'Objectives',''),(26,2,1,3,NULL,'Materials',''),(27,2,1,3,NULL,'Lesson Plan Text',''),(28,2,2,3,NULL,'URL',''),(29,2,2,3,NULL,'Event Type',''),(30,2,1,3,NULL,'Participants','Names of individuals or groups participating in the event.'),(31,2,9,3,NULL,'Birth Date',''),(32,2,2,3,NULL,'Birthplace',''),(33,2,9,3,NULL,'Death Date',''),(34,2,2,3,NULL,'Occupation',''),(35,2,1,3,NULL,'Biographical Text',''),(36,2,1,3,NULL,'Bibliography',''),(37,1,2,1,8,'Contributor','An entity responsible for making contributions to the resource. Examples of a Contributor include a person, an organization, or a service. Typically, the name of a Contributor should be used to indicate the entity.'),(38,1,2,1,15,'Coverage','The spatial or temporal topic of the resource, the spatial applicability of the resource, or the jurisdiction under which the resource is relevant. Spatial topic and spatial applicability may be a named place or a location specified by its geographic coordinates. Temporal topic may be a named period, date, or date range. A jurisdiction may be a named administrative entity or a geographic place to which the resource applies. Recommended best practice is to use a controlled vocabulary such as the Thesaurus of Geographic Names [TGN]. Where appropriate, named places or time periods can be used in preference to numeric identifiers such as sets of coordinates or date ranges.'),(39,1,2,1,4,'Creator','An entity primarily responsible for making the resource. Examples of a Creator include a person, an organization, or a service. Typically, the name of a Creator should be used to indicate the entity.'),(40,1,2,1,7,'Date','A point or period of time associated with an event in the lifecycle of the resource. Date may be used to express temporal information at any level of granularity. Recommended best practice is to use an encoding scheme, such as the W3CDTF profile of ISO 8601 [W3CDTF].'),(41,1,1,1,3,'Description','An account of the resource. Description may include but is not limited to: an abstract, a table of contents, a graphical representation, or a free-text account of the resource.'),(42,1,2,1,11,'Format','The file format, physical medium, or dimensions of the resource. Examples of dimensions include size and duration. Recommended best practice is to use a controlled vocabulary such as the list of Internet Media Types [MIME].'),(43,1,2,1,14,'Identifier','An unambiguous reference to the resource within a given context. Recommended best practice is to identify the resource by means of a string conforming to a formal identification system.'),(44,1,2,1,12,'Language','A language of the resource. Recommended best practice is to use a controlled vocabulary such as RFC 4646 [RFC4646].'),(45,1,2,1,6,'Publisher','An entity responsible for making the resource available. Examples of a Publisher include a person, an organization, or a service. Typically, the name of a Publisher should be used to indicate the entity.'),(46,1,2,1,10,'Relation','A related resource. Recommended best practice is to identify the related resource by means of a string conforming to a formal identification system.'),(47,1,2,1,9,'Rights','Information about rights held in and over the resource. Typically, rights information includes a statement about various property rights associated with the resource, including intellectual property rights.'),(48,1,2,1,5,'Source','A related resource from which the described resource is derived. The described resource may be derived from the related resource in whole or in part. Recommended best practice is to identify the related resource by means of a string conforming to a formal identification system.'),(49,1,2,1,2,'Subject','The topic of the resource. Typically, the subject will be represented using keywords, key phrases, or classification codes. Recommended best practice is to use a controlled vocabulary. To describe the spatial or temporal topic of the resource, use the Coverage element.'),(50,1,2,1,1,'Title','A name given to the resource. Typically, a Title will be a name by which the resource is formally known.'),(51,1,2,1,13,'Type','The nature or genre of the resource. Recommended best practice is to use a controlled vocabulary such as the DCMI Type Vocabulary [DCMITYPE]. To describe the file format, physical medium, or dimensions of the resource, use the Format element.'),(58,3,1,4,1,'Additional Creator',''),(59,3,1,4,2,'Transcriber',''),(60,3,1,4,3,'Producer',''),(61,3,1,4,4,'Render Device',''),(62,3,1,4,5,'Render Details',''),(63,3,10,4,6,'Capture Date',''),(64,3,1,4,7,'Capture Device',''),(65,3,1,4,8,'Capture Details',''),(66,3,1,4,9,'Change History',''),(67,3,1,4,10,'Watermark',''),(69,3,1,4,12,'Encryption',''),(70,3,1,4,13,'Compression',''),(71,3,1,4,14,'Post Processing',''),(72,3,4,5,1,'Width',''),(73,3,4,5,2,'Height',''),(74,3,4,5,3,'Bit Depth',''),(75,3,4,5,4,'Channels',''),(76,3,1,5,5,'Exif String',''),(77,3,1,5,6,'Exif Array',''),(78,3,1,5,7,'IPTC String',''),(79,3,1,5,8,'IPTC Array',''),(80,3,4,6,1,'Bitrate',''),(81,3,4,6,2,'Duration',''),(82,3,4,6,3,'Sample Rate',''),(83,3,1,6,4,'Codec',''),(84,3,4,6,5,'Width',''),(85,3,4,6,6,'Height','');
/*!40000 ALTER TABLE `omeka_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_entities`
--

DROP TABLE IF EXISTS `omeka_entities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_entities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` text COLLATE utf8_unicode_ci,
  `middle_name` text COLLATE utf8_unicode_ci,
  `last_name` text COLLATE utf8_unicode_ci,
  `email` text COLLATE utf8_unicode_ci,
  `institution` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_entities`
--

LOCK TABLES `omeka_entities` WRITE;
/*!40000 ALTER TABLE `omeka_entities` DISABLE KEYS */;
INSERT INTO `omeka_entities` VALUES (1,'Super',NULL,'User','neatline@scholarslab.org',NULL);
/*!40000 ALTER TABLE `omeka_entities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_entities_relations`
--

DROP TABLE IF EXISTS `omeka_entities_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_entities_relations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entity_id` int(10) unsigned DEFAULT NULL,
  `relation_id` int(10) unsigned DEFAULT NULL,
  `relationship_id` int(10) unsigned DEFAULT NULL,
  `type` enum('Item','Collection','Exhibit') COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `relation_type` (`type`),
  KEY `relation` (`relation_id`),
  KEY `relationship` (`relationship_id`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_entities_relations`
--

LOCK TABLES `omeka_entities_relations` WRITE;
/*!40000 ALTER TABLE `omeka_entities_relations` DISABLE KEYS */;
INSERT INTO `omeka_entities_relations` VALUES (23,1,23,1,'Item','2012-08-30 19:45:58'),(24,1,24,1,'Item','2012-08-30 19:46:40'),(25,1,25,1,'Item','2012-08-30 19:49:21'),(26,1,26,1,'Item','2012-08-30 19:52:16'),(27,1,27,1,'Item','2012-08-30 19:52:35'),(28,1,28,1,'Item','2012-08-30 19:52:52'),(29,1,29,1,'Item','2012-08-30 19:53:10'),(30,1,30,1,'Item','2012-08-30 19:53:29'),(31,1,31,1,'Item','2012-08-30 19:53:44'),(32,1,32,1,'Item','2012-08-30 19:54:03'),(33,1,33,1,'Item','2012-08-30 19:54:26'),(34,1,34,1,'Item','2012-08-30 19:54:44'),(35,1,35,1,'Item','2012-08-30 19:55:35'),(36,1,36,1,'Item','2012-08-30 19:55:48'),(37,1,37,1,'Item','2012-08-30 19:56:01'),(38,1,38,1,'Item','2012-08-30 19:57:12'),(39,1,39,1,'Item','2012-08-30 19:59:18'),(40,1,40,1,'Item','2012-08-30 19:59:27'),(41,1,41,1,'Item','2012-08-30 20:00:09'),(42,1,42,1,'Item','2012-08-30 20:00:22'),(43,1,43,1,'Item','2012-08-30 20:00:40'),(44,1,44,1,'Item','2012-08-30 20:01:12'),(45,1,45,1,'Item','2012-08-30 20:15:41'),(47,1,47,1,'Item','2012-09-04 21:08:22'),(48,1,48,1,'Item','2012-09-04 21:09:37'),(49,1,49,1,'Item','2012-09-04 21:09:52'),(50,1,50,1,'Item','2012-09-04 21:12:03'),(51,1,51,1,'Item','2012-09-04 21:15:49'),(52,1,52,1,'Item','2012-09-04 21:16:02'),(53,1,53,1,'Item','2012-09-04 21:16:16'),(54,1,54,1,'Item','2012-09-04 21:16:31'),(55,1,55,1,'Item','2012-09-04 21:16:46'),(56,1,56,1,'Item','2012-09-04 21:17:02'),(57,1,57,1,'Item','2012-09-04 21:17:19'),(58,1,58,1,'Item','2012-09-04 21:17:36'),(59,1,59,1,'Item','2012-09-04 21:17:48'),(60,1,60,1,'Item','2012-09-04 21:18:40'),(61,1,61,1,'Item','2012-09-04 21:18:55'),(62,1,62,1,'Item','2012-09-04 21:19:11'),(63,1,63,1,'Item','2012-09-04 21:20:24'),(64,1,64,1,'Item','2012-09-04 21:22:39'),(65,1,65,1,'Item','2012-09-04 21:22:47'),(66,1,66,1,'Item','2012-09-04 21:23:27'),(67,1,67,1,'Item','2012-09-04 21:23:38'),(68,1,68,1,'Item','2012-09-04 21:23:56'),(69,1,69,1,'Item','2012-09-04 21:24:30'),(76,1,76,1,'Item','2012-09-04 22:49:29'),(77,1,77,1,'Item','2012-09-04 22:54:46'),(78,1,78,1,'Item','2012-09-04 22:56:12');
/*!40000 ALTER TABLE `omeka_entities_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_entity_relationships`
--

DROP TABLE IF EXISTS `omeka_entity_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_entity_relationships` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_entity_relationships`
--

LOCK TABLES `omeka_entity_relationships` WRITE;
/*!40000 ALTER TABLE `omeka_entity_relationships` DISABLE KEYS */;
INSERT INTO `omeka_entity_relationships` VALUES (1,'added',NULL),(2,'modified',NULL),(3,'favorite',NULL),(4,'collector',NULL);
/*!40000 ALTER TABLE `omeka_entity_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_files`
--

DROP TABLE IF EXISTS `omeka_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `size` int(10) unsigned NOT NULL,
  `has_derivative_image` tinyint(1) NOT NULL,
  `authentication` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime_browser` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime_os` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_os` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `archive_filename` text COLLATE utf8_unicode_ci NOT NULL,
  `original_filename` text COLLATE utf8_unicode_ci NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `added` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `stored` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_files`
--

LOCK TABLES `omeka_files` WRITE;
/*!40000 ALTER TABLE `omeka_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_item_types`
--

DROP TABLE IF EXISTS `omeka_item_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_item_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_item_types`
--

LOCK TABLES `omeka_item_types` WRITE;
/*!40000 ALTER TABLE `omeka_item_types` DISABLE KEYS */;
INSERT INTO `omeka_item_types` VALUES (1,'Document','A resource containing textual data.  Note that facsimiles or images of texts are still of the genre text.'),(3,'Moving Image','A series of visual representations that, when shown in succession, impart an impression of motion.'),(4,'Oral History','A resource containing historical information obtained in interviews with persons having firsthand knowledge.'),(5,'Sound','A resource whose content is primarily intended to be rendered as audio.'),(6,'Still Image','A static visual representation. Examples of still images are: paintings, drawings, graphic designs, plans and maps.  Recommended best practice is to assign the type \"text\" to images of textual materials.'),(7,'Website','A resource comprising of a web page or web pages and all related assets ( such as images, sound and video files, etc. ).'),(8,'Event','A non-persistent, time-based occurrence.  Metadata for an event provides descriptive information that is the basis for discovery of the purpose, location, duration, and responsible agents associated with an event. Examples include an exhibition, webcast, conference, workshop, open day, performance, battle, trial, wedding, tea party, conflagration.'),(9,'Email','A resource containing textual messages and binary attachments sent electronically from one person to another or one person to many people.'),(10,'Lesson Plan','Instructional materials.'),(11,'Hyperlink','Title, URL, Description or annotation.'),(12,'Person','An individual, biographical data, birth and death, etc.'),(13,'Interactive Resource','A resource requiring interaction from the user to be understood, executed, or experienced. Examples include forms on Web pages, applets, multimedia learning objects, chat services, or virtual reality environments.');
/*!40000 ALTER TABLE `omeka_item_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_item_types_elements`
--

DROP TABLE IF EXISTS `omeka_item_types_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_item_types_elements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_type_id` int(10) unsigned NOT NULL,
  `element_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_type_id_element_id` (`item_type_id`,`element_id`),
  KEY `item_type_id` (`item_type_id`),
  KEY `element_id` (`element_id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_item_types_elements`
--

LOCK TABLES `omeka_item_types_elements` WRITE;
/*!40000 ALTER TABLE `omeka_item_types_elements` DISABLE KEYS */;
INSERT INTO `omeka_item_types_elements` VALUES (1,1,7,NULL),(2,1,1,NULL),(3,6,7,NULL),(6,6,10,NULL),(7,3,7,NULL),(8,3,11,NULL),(9,3,12,NULL),(10,3,13,NULL),(11,3,14,NULL),(12,3,5,NULL),(13,5,7,NULL),(14,5,11,NULL),(15,5,15,NULL),(16,5,5,NULL),(17,4,7,NULL),(18,4,11,NULL),(19,4,15,NULL),(20,4,5,NULL),(21,4,2,NULL),(22,4,3,NULL),(23,4,4,NULL),(24,4,16,NULL),(25,9,17,NULL),(26,9,18,NULL),(27,9,20,NULL),(28,9,19,NULL),(29,9,21,NULL),(30,9,22,NULL),(31,9,23,NULL),(32,10,24,NULL),(33,10,25,NULL),(34,10,26,NULL),(35,10,11,NULL),(36,10,27,NULL),(37,7,6,NULL),(38,11,28,NULL),(39,8,29,NULL),(40,8,30,NULL),(41,8,11,NULL),(42,12,31,NULL),(43,12,32,NULL),(44,12,33,NULL),(45,12,34,NULL),(46,12,35,NULL),(47,12,36,NULL);
/*!40000 ALTER TABLE `omeka_item_types_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_items`
--

DROP TABLE IF EXISTS `omeka_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_type_id` int(10) unsigned DEFAULT NULL,
  `collection_id` int(10) unsigned DEFAULT NULL,
  `featured` tinyint(4) NOT NULL,
  `public` tinyint(4) NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `added` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `item_type_id` (`item_type_id`),
  KEY `collection_id` (`collection_id`),
  KEY `public` (`public`),
  KEY `featured` (`featured`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_items`
--

LOCK TABLES `omeka_items` WRITE;
/*!40000 ALTER TABLE `omeka_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_mime_element_set_lookup`
--

DROP TABLE IF EXISTS `omeka_mime_element_set_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_mime_element_set_lookup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `element_set_id` int(10) unsigned NOT NULL,
  `mime` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mime` (`mime`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_mime_element_set_lookup`
--

LOCK TABLES `omeka_mime_element_set_lookup` WRITE;
/*!40000 ALTER TABLE `omeka_mime_element_set_lookup` DISABLE KEYS */;
INSERT INTO `omeka_mime_element_set_lookup` VALUES (1,5,'image/bmp'),(2,5,'image/gif'),(3,5,'image/ief'),(4,5,'image/jpeg'),(5,5,'image/pict'),(6,5,'image/pjpeg'),(7,5,'image/png'),(8,5,'image/tiff'),(9,5,'image/vnd.rn-realflash'),(10,5,'image/vnd.rn-realpix'),(11,5,'image/vnd.wap.wbmp'),(12,5,'image/x-icon'),(13,5,'image/x-jg'),(14,5,'image/x-jps'),(15,5,'image/x-niff'),(16,5,'image/x-pcx'),(17,5,'image/x-pict'),(18,5,'image/x-quicktime'),(19,5,'image/x-rgb'),(20,5,'image/x-tiff'),(21,5,'image/x-windows-bmp'),(22,5,'image/x-xbitmap'),(23,5,'image/x-xbm'),(24,5,'image/x-xpixmap'),(25,5,'image/x-xwd'),(26,5,'image/x-xwindowdump'),(27,6,'video/x-msvideo'),(28,6,'video/avi'),(29,6,'video/msvideo'),(30,6,'video/x-mpeg'),(31,6,'video/x-ms-asf'),(32,6,'video/mpeg'),(33,6,'video/quicktime'),(34,6,'video/x-ms-wmv');
/*!40000 ALTER TABLE `omeka_mime_element_set_lookup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_neatline_features`
--

DROP TABLE IF EXISTS `omeka_neatline_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_neatline_features` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `item_id` int(10) unsigned NOT NULL,
  `element_text_id` int(10) unsigned NOT NULL,
  `is_map` tinyint(1) NOT NULL DEFAULT '0',
  `wkt` text COLLATE utf8_unicode_ci,
  `zoom` smallint(2) NOT NULL DEFAULT '3',
  `center_lon` decimal(20,7) NOT NULL DEFAULT '0.0000000',
  `center_lat` decimal(20,7) NOT NULL DEFAULT '0.0000000',
  `base_layer` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`,`element_text_id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_neatline_features`
--

LOCK TABLES `omeka_neatline_features` WRITE;
/*!40000 ALTER TABLE `omeka_neatline_features` DISABLE KEYS */;
INSERT INTO `omeka_neatline_features` VALUES (31,'2012-08-30 17:45:58',23,72,1,'POINT(-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','gphy'),(32,'2012-08-30 17:46:40',24,74,1,'POINT(-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','gphy'),(33,'2012-08-30 17:49:21',25,76,1,'POINT(-12480784.245694 4995440.5620728)',10,'-12454795.6560810','4975536.3603766','osm'),(34,'2012-08-30 17:52:16',26,79,1,'POINT(-3326539.4705078 2547917.8171078)|LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(35,'2012-08-30 17:52:35',27,82,1,'POINT(-3326539.4705078 4269891.1900765)',0,'0.0000000','0.0000000','osm'),(36,'2012-08-30 17:52:52',28,85,0,'',0,'0.0000000','0.0000000','osm'),(37,'2012-08-30 17:52:52',28,86,0,'',0,'0.0000000','0.0000000','osm'),(38,'2012-08-30 17:53:10',29,89,1,'POINT(-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(39,'2012-08-30 17:53:10',29,90,1,'LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(40,'2012-08-30 17:53:29',30,93,1,'POINT(-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(41,'2012-08-30 17:53:29',30,94,0,'',0,'0.0000000','0.0000000','osm'),(42,'2012-08-30 17:53:44',31,97,0,'',0,'0.0000000','0.0000000','osm'),(43,'2012-08-30 17:53:44',31,98,0,'',0,'0.0000000','0.0000000','osm'),(44,'2012-08-30 17:54:03',32,101,1,'POINT(-3326539.4705078 3056682.6773031)',0,'0.0000000','0.0000000','osm'),(45,'2012-08-30 17:54:03',32,102,1,'LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(46,'2012-08-30 17:54:26',33,105,1,'POINT(-3326539.4705078 3779063.6520437)',0,'0.0000000','0.0000000','osm'),(47,'2012-08-30 17:54:26',33,106,0,'',0,'0.0000000','0.0000000','osm'),(48,'2012-08-30 17:54:44',34,109,0,'',0,'0.0000000','0.0000000','osm'),(49,'2012-08-30 17:55:35',35,112,1,'POINT(-3326539.4705078 2547917.8171078)|LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(50,'2012-08-30 17:55:48',36,115,1,'POINT(-3326539.4705078 2547917.8171078)|LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(51,'2012-08-30 17:57:12',38,120,1,'POINT(-3326539.4705078 2547917.8171078)|LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(52,'2012-08-30 17:59:18',39,123,0,'',0,'0.0000000','0.0000000','osm'),(53,'2012-08-30 17:59:27',40,126,0,'',0,'0.0000000','0.0000000','osm'),(54,'2012-08-30 18:00:09',41,128,1,'POINT(-9155033.8066061 4903054.3228481)',6,'-8739216.3727926','4584587.0957096','osm'),(55,'2012-08-30 18:00:22',42,131,0,'',0,'0.0000000','0.0000000','osm'),(56,'2012-08-30 18:00:22',42,132,0,'',0,'0.0000000','0.0000000','osm'),(57,'2012-08-30 18:00:40',43,135,1,'LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(58,'2012-08-30 18:00:40',43,136,1,'POINT(-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(59,'2012-08-30 18:01:12',44,139,1,'LINESTRING(-3326539.4705078 2782732.3679672,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(60,'2012-08-30 18:15:41',45,142,1,'LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(61,'2012-08-30 18:15:41',45,143,0,'',0,'0.0000000','0.0000000','osm'),(63,'2012-09-04 19:08:22',47,146,1,'POINT(-12480784.245694 4995440.5620728)',10,'-12454795.6560810','4975536.3603766','osm'),(64,'2012-09-04 19:09:37',48,148,1,'POINT(-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','gphy'),(65,'2012-09-04 19:09:52',49,150,1,'POINT(-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','gphy'),(66,'2012-09-04 19:12:03',50,152,1,'POINT(-12480784.245694 4995440.5620728)',10,'-12454795.6560810','4975536.3603766','osm'),(67,'2012-09-04 19:15:49',51,155,1,'POINT(-3326539.4705078 2547917.8171078)|LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(68,'2012-09-04 19:16:02',52,158,1,'POINT(-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(69,'2012-09-04 19:16:16',53,161,0,'',0,'0.0000000','0.0000000','osm'),(70,'2012-09-04 19:16:16',53,162,0,'',0,'0.0000000','0.0000000','osm'),(71,'2012-09-04 19:16:31',54,165,1,'POINT(-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(72,'2012-09-04 19:16:31',54,166,1,'LINESTRING(-3326539.4705078 6735444.2726821,-3326539.4705078 3017546.9188265)',0,'0.0000000','0.0000000','osm'),(73,'2012-09-04 19:16:46',55,169,1,'POINT(-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(74,'2012-09-04 19:16:46',55,170,0,'',0,'0.0000000','0.0000000','osm'),(75,'2012-09-04 19:17:02',56,173,0,'',0,'0.0000000','0.0000000','osm'),(76,'2012-09-04 19:17:02',56,174,0,'',0,'0.0000000','0.0000000','osm'),(77,'2012-09-04 19:17:19',57,177,1,'POINT(-3326539.4705078 2587053.5755844)',0,'0.0000000','0.0000000','osm'),(78,'2012-09-04 19:17:19',57,178,1,'LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(79,'2012-09-04 19:17:36',58,181,1,'POINT(-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(80,'2012-09-04 19:17:36',58,182,0,'',0,'0.0000000','0.0000000','osm'),(81,'2012-09-04 19:17:48',59,185,0,'',0,'0.0000000','0.0000000','osm'),(82,'2012-09-04 19:18:40',60,188,1,'POINT(-3326539.4705078 2567485.6963461)|LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(83,'2012-09-04 19:18:55',61,191,1,'POINT(-3326539.4705078 2704460.851014)|LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(84,'2012-09-04 19:20:24',63,196,1,'POINT(-3326539.4705078 3367812.1363411)|LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(85,'2012-09-04 19:22:39',64,199,0,'',0,'0.0000000','0.0000000','osm'),(86,'2012-09-04 19:22:47',65,202,0,'',0,'0.0000000','0.0000000','osm'),(87,'2012-09-04 19:23:27',66,204,1,'POINT(-9155033.8066061 4903054.3228481)',6,'-8739216.3727926','4584587.0957096','osm'),(88,'2012-09-04 19:23:38',67,207,0,'',0,'0.0000000','0.0000000','osm'),(89,'2012-09-04 19:23:38',67,208,0,'',0,'0.0000000','0.0000000','osm'),(90,'2012-09-04 19:23:56',68,211,1,'LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(91,'2012-09-04 19:23:56',68,212,1,'POINT(-3326539.4705078 3721990.5714047)',0,'0.0000000','0.0000000','osm'),(92,'2012-09-04 19:24:30',69,215,1,'LINESTRING(-3326539.4705078 2547917.8171078,-3326539.4705078 2547917.8171078)',0,'0.0000000','0.0000000','osm'),(93,'2012-09-04 19:24:30',69,216,0,'',0,'0.0000000','0.0000000','osm'),(97,'2012-09-04 20:49:29',76,227,1,'POINT(-12480784.245694 4995440.5620728)',10,'-12454795.6560810','4975536.3603766','osm'),(98,'2012-09-04 20:54:46',77,229,1,'POINT(-12480784.245694 4995440.5620728)',10,'-12454795.6560810','4975536.3603766','osm'),(99,'2012-09-04 20:56:12',78,231,1,'POINT(-12480784.245694 4995440.5620728)',10,'-12454795.6560810','4975536.3603766','osm');
/*!40000 ALTER TABLE `omeka_neatline_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_options`
--

DROP TABLE IF EXISTS `omeka_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_options`
--

LOCK TABLES `omeka_options` WRITE;
/*!40000 ALTER TABLE `omeka_options` DISABLE KEYS */;
INSERT INTO `omeka_options` VALUES (1,'omeka_version','1.5.3'),(2,'administrator_email','neatline@scholarslab.org'),(3,'copyright',''),(4,'site_title','NeatlineFeatures Travis CI'),(5,'author',''),(6,'description',''),(7,'thumbnail_constraint','200'),(8,'square_thumbnail_constraint','200'),(9,'fullsize_constraint','800'),(10,'per_page_admin','10'),(11,'per_page_public','10'),(12,'show_empty_elements','0'),(13,'path_to_convert','/usr/bin'),(14,'admin_theme','default'),(15,'public_theme','default'),(16,'file_extension_whitelist','aac,aif,aiff,asf,asx,avi,bmp,c,cc,class,css,divx,doc,docx,exe,gif,gz,gzip,h,ico,j2k,jp2,jpe,jpeg,jpg,m4a,mdb,mid,midi,mov,mp2,mp3,mp4,mpa,mpe,mpeg,mpg,mpp,odb,odc,odf,odg,odp,ods,odt,ogg, pdf,png,pot,pps,ppt,pptx,qt,ra,ram,rtf,rtx,swf,tar,tif,tiff,txt, wav,wax,wma,wmv,wmx,wri,xla,xls,xlsx,xlt,xlw,zip'),(17,'file_mime_type_whitelist','application/msword,application/ogg,application/pdf,application/rtf,application/vnd.ms-access,application/vnd.ms-excel,application/vnd.ms-powerpoint,application/vnd.ms-project,application/vnd.ms-write,application/vnd.oasis.opendocument.chart,application/vnd.oasis.opendocument.database,application/vnd.oasis.opendocument.formula,application/vnd.oasis.opendocument.graphics,application/vnd.oasis.opendocument.presentation,application/vnd.oasis.opendocument.spreadsheet,application/vnd.oasis.opendocument.text,application/x-ms-wmp,application/x-ogg,application/x-gzip,application/x-msdownload,application/x-shockwave-flash,application/x-tar,application/zip,audio/aac,audio/aiff,audio/mid,audio/midi,audio/mp3,audio/mp4,audio/mpeg,audio/mpeg3,audio/ogg,audio/wav,audio/wma,audio/x-aac,audio/x-aiff,audio/x-midi,audio/x-mp3,audio/x-mp4,audio/x-mpeg,audio/x-mpeg3,audio/x-mpegaudio,audio/x-ms-wax,audio/x-realaudio,audio/x-wav,audio/x-wma,image/bmp,image/gif,image/icon,image/jpeg,image/pjpeg,image/png,image/tiff,image/x-icon,image/x-ms-bmp,text/css,text/plain,text/richtext,text/rtf,video/asf,video/avi,video/divx,video/mp4,video/mpeg,video/msvideo,video/ogg,video/quicktime,video/x-ms-wmv,video/x-msvideo'),(18,'disable_default_file_validation',''),(19,'display_system_info','1'),(20,'tag_delimiter',','),(24,'omeka_update','a:2:{s:14:\"latest_version\";s:5:\"1.5.3\";s:12:\"last_updated\";i:1346938557;}');
/*!40000 ALTER TABLE `omeka_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_plugins`
--

DROP TABLE IF EXISTS `omeka_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_plugins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL,
  `version` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `active_idx` (`active`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_plugins`
--

LOCK TABLES `omeka_plugins` WRITE;
/*!40000 ALTER TABLE `omeka_plugins` DISABLE KEYS */;
INSERT INTO `omeka_plugins` VALUES (1,'NeatlineFeatures',1,'1.0.0');
/*!40000 ALTER TABLE `omeka_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_processes`
--

DROP TABLE IF EXISTS `omeka_processes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_processes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned DEFAULT NULL,
  `status` enum('starting','in progress','completed','paused','error','stopped') COLLATE utf8_unicode_ci NOT NULL,
  `args` text COLLATE utf8_unicode_ci NOT NULL,
  `started` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `stopped` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `pid` (`pid`),
  KEY `started` (`started`),
  KEY `stopped` (`stopped`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_processes`
--

LOCK TABLES `omeka_processes` WRITE;
/*!40000 ALTER TABLE `omeka_processes` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_processes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_record_types`
--

DROP TABLE IF EXISTS `omeka_record_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_record_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_record_types`
--

LOCK TABLES `omeka_record_types` WRITE;
/*!40000 ALTER TABLE `omeka_record_types` DISABLE KEYS */;
INSERT INTO `omeka_record_types` VALUES (1,'All','Elements, element sets, and element texts assigned to this record type relate to all possible records.'),(2,'Item','Elements, element sets, and element texts assigned to this record type relate to item records.'),(3,'File','Elements, element sets, and element texts assigned to this record type relate to file records.');
/*!40000 ALTER TABLE `omeka_record_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_schema_migrations`
--

DROP TABLE IF EXISTS `omeka_schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_schema_migrations` (
  `version` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_schema_migrations`
--

LOCK TABLES `omeka_schema_migrations` WRITE;
/*!40000 ALTER TABLE `omeka_schema_migrations` DISABLE KEYS */;
INSERT INTO `omeka_schema_migrations` VALUES ('20100401000000'),('20100810120000'),('20110113000000'),('20110124000001'),('20110301103900'),('20110328192100'),('20110426181300'),('20110601112200'),('20110627223000'),('20110824110000'),('20120112100000');
/*!40000 ALTER TABLE `omeka_schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_sessions`
--

DROP TABLE IF EXISTS `omeka_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_sessions` (
  `id` char(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `modified` bigint(20) DEFAULT NULL,
  `lifetime` int(11) DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_sessions`
--

LOCK TABLES `omeka_sessions` WRITE;
/*!40000 ALTER TABLE `omeka_sessions` DISABLE KEYS */;
INSERT INTO `omeka_sessions` VALUES ('004oetfnoqcl1nlb16n70udek3',1346349646,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('00vi5r3c7vlp3m6r5u04s4sbm3',1346785797,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('03f3vgt1ha9briq577q57s0b20',1346784065,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('0e27bnejg0cb9u69uio12mu6u7',1346349437,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('0plh5mm58lap1g65i10r9lad45',1346349316,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('1bhrrq378hivsbl7sj90iin1d3',1346783185,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('1c1klpn3rs8pi5sp0loumoal76',1346350546,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('1chuvrlodgphk09bevn0crakv1',1346783254,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('26c64fba6mqt008hmnssi1bf84',1346349612,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('2fuk4n7hs3q8b0totblet7ks43',1346252817,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('2lfc8oo93d9pnib1p9vepuhqq0',1346251841,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('2v83rjhaere0tut983adn9fvj2',1346349196,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('357bbp14rq4ihc9qlq83b490n4',1346349161,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('3fat70858qtg03g9kae32t63d7',1346349338,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('3jk2bb08g2eg1pfoqshbg7qqf2',1346786433,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('3pep7t6s9tatogl5ff267oied6',1346786562,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('3rklvhucqt8epsuvol18kfifs0',1346786077,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('409htnpreoogi2f9v7kqhp7hn2',1346786180,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('43g85tge6na8ftqq7pia0ocnv3',1346782616,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('44dms6ht5lskhs5r44gb7qckn6',1346782781,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('46jlvprukmj0ai4c56uf1uqep7',1346786644,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('4f4q783l2iqnt9eqhjl9imc336',1346349295,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('4m5mofptn0vpd8km7p50thtcf4',1346348838,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('4u1sh6nfkseb65cm8jfneanio3',1346785705,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('508jqg6qcg4kc2ncvmu02g51f6',1346349324,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('55uugcev5j8c7m3oimjuiomuv7',1346790296,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}'),('57moiilqrhsfeh5qk5ij90rqn6',1346251643,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('58lk499ijgv3uti2oplran4n45',1346784755,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('5d0o0e4e0d1flg51tja3rqo2m2',1346786343,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('5e94tiurjahjj3947pb72nmqu0',1346349177,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('5go8f12c8rrvhboteh6i4ck154',1346785908,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('5hiul7os5uif3km45sf7r67ot5',1346252729,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('5i8ur73vrlk0amm9v2fkspuir1',1346786591,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('5vdm5q21gb78vvrs7537o7abo0',1346350495,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('63q1808mi9fnkah2hhbfe60t85',1346357517,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('644gm3g1fc73usvvugih5rs1l0',1346785763,1209600,'flash|a:1:{s:6:\"status\";N;}'),('65d13l1hhj2r36dctaak4121o5',1346786261,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('662an4v2i6stbl839m9stis9a5',1346252028,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('69kd5abqb8na9e95snh41kjnq1',1346786167,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('6iipagclf4fgh3spn3lsj6jko3',1346252421,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('6r8ff5dvl84uvrphc6856mnnd7',1346252207,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('6vkeblunll0p34sl8iuvgpvel1',1346252576,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('70f8f7u8g0j7f5nolqc9k5iuu5',1346252772,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('74k6i1qvrn2ddm8is5n8sunlm6',1346785804,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('77jv4vkl80usm6bkkjgt0ar5r5',1346783414,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('7aa6ghavd2ema5e0j44dst9ku1',1346786324,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('7u8n8sap6m6pluqvn5ogm0tm53',1346785999,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('83iblae7ttqlv82nglf30bsr85',1346792175,1209600,'Default|a:1:{s:8:\"redirect\";s:19:\"//admin/users/login\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}flash|a:1:{s:6:\"status\";N;}'),('84dja2ocnd4eih3rn5cqqsih54',1346251915,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('8bed9bdcuevs67e6ss5n5cdrn0',1346786585,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('8ck12ou66kfq2ibp4b0aaorjd0',1346783272,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('8lrql2pb5kqm4p2lsve4fp3230',1346357508,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('8vk1f4knjvqg0vv7a59ofn4li7',1346349560,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('970s8n237tc4o299ejml2uvtt1',1346251734,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('9a9ps307fhmjdves0ddt00o7i0',1346252569,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('9hkub4pfu75vunqucqemntamm2',1346349045,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('9hsjpbulm6hp755b4ijfpe4p82',1346256014,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('9ns25ok5f5ih1dljoctpjd11d0',1346349586,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('9t750scv1c24lc03g3gjkebhe0',1346252321,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('at05vup6afmreai5seae9cvtv2',1346248915,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('b1ns95qrvtfd7h60i1qsmkq1m4',1346783820,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('b44aasknhitr8rg5ju4ioqjqm2',1346783279,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('b5ptsp2f46mve8vn0ov4g0qnu0',1346348964,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('b9e0c9u8tvhj6kqvumjab004g1',1346258091,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('b9fibouq968csrp7ko9u7eipq2',1346252230,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('b9jpnuvvgt4iarel4vufe69ll4',1346349594,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('bakbms60ihh57gk93vupfkhbc1',1346348872,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('bcefgblqi70hc3krkeqd03vt00',1346351988,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('bk42kji74hc0ijju4n796ona37',1346786610,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('boferpf7e9j1kii74e7kvrvs43',1346783899,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('c30p1rqre0ktjtouphaer14mj2',1346783926,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('c6h3mb8rgq3jliuelsinf8dr46',1346792089,1209600,'Default|a:1:{s:8:\"redirect\";s:19:\"//admin/users/login\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}flash|a:1:{s:6:\"status\";N;}'),('c7j7bc0287ar7lit48c1u731f1',1346786355,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('c7n6h9v0mic2tr28p7cu6tbtc6',1346786153,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('cd6p2stoian0viqoh8dv1kr4t6',1346349571,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('cmmqj0p7t78hk7l16l48t5k193',1346252249,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('d0io45ljcatu603a3dmh6vded7',1346251957,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('d5metf41run59abj8506tghf54',1346349034,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('d90h3qlo1gkk7pb4qf0hakfk40',1346252837,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('dabgjjkgct7mje668c4tde7jn4',1346792079,1209600,'Default|a:1:{s:8:\"redirect\";s:19:\"//admin/users/login\";}flash|a:1:{s:6:\"status\";N;}'),('ddda7u4haritigvqrf1ikqgj57',1346782546,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ddfucba2stp29ju9j0647ap2d3',1346348936,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('dgvsko7aqff88asfmeeh2nm7d2',1346783345,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('dj0hlg0pcmjtkbgicrft1shee3',1346252483,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('dtr8pt64oq4c7ec6sq749m5k66',1346349678,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('dvvsnhcbs835p0fr66fjrajmm0',1346783117,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('e1t2qmf9vf89r1t0dmajvdgqg3',1346785766,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('e2ng3qh11eo6gda8d4emsa04k2',1346789805,1209600,''),('e4m4gpoef6c8kmsblotgf3u1c4',1346252449,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('e5br55kgdgkrlu1r0vdl3vkhr5',1346350679,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('e99nh016mpktrfrdm7a5a5egu2',1346783038,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('e9qgtn1iq86b6r9ler2d3ar5u6',1346349365,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ebbski01iaaobibop79rn5j9u7',1346251781,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ec1p2rg23rvmh7sdnenrogke20',1346348722,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('edl8flp3cvmvkuvmevhha5d652',1346786429,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('eetq1901tpqokihaek5lvmtlr1',1346783886,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ehdikfi9866ti0gp2k9d6hick7',1346791761,1209600,''),('eksk1a0iqjbu5ibo13de16dvp2',1346791772,1209600,'Default|a:1:{s:8:\"redirect\";s:19:\"//admin/users/login\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}flash|a:1:{s:6:\"status\";N;}'),('evi4h5faqh0untm5k4eok0htv2',1346784401,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('f111all7m450hcdfpfbn2dlvt0',1346252368,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('f1d3j4d5gb8fqsq13e2252pm12',1346789810,1209600,''),('fa4rno11u59h9p5da9t7q1rk33',1346786674,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('fac23426iecilai2emlheojil7',1346786244,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ffdv4e4gsnkfps30njpmevl7v5',1346352039,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('flljjp6i9iicb22iv5hntusaf0',1346351410,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('fnjmohgsf6vl8rh1ackpveij37',1346252394,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('g642b5s1uu72o5t9jf4tuffbn3',1346783548,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('g7pihl5fhmjrjrosub1ammlqn3',1346349310,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ga015c4fdmpp7td936p86igmj1',1346252274,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ge18d6g9ud1a0hs0c0ojkneg64',1346349122,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('gm787v694d7kaps0vd3psvuh42',1346349229,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('gn1u8klhtt62a350vvp4bd3rl5',1346785840,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('gplm88m4up34t76u8kp9kpe872',1346349214,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('h1tuuj2lbk1s3pagv34jrvee11',1346782425,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('h6qh0bev6hka722qe9tq3s7e74',1346784149,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('hbci1pab71knh48ufv6f1bp7r2',1346783920,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('hhqjvt01b1lt6rdges1rnfd941',1346252387,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('hm6t4nu76nvmepcdofdglq1b42',1346786300,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('j53nl1n50chbci8jgvvm2vkga5',1346785926,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('jgb8qf7459emptl9m9n01agin6',1346782771,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('jhbbe17l9fgutbukbj43jkvl96',1346786571,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('jhig3fujd0ndt68f6t3mojcl21',1346783682,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('jjffg3qce09mk7hodpcuardaj0',1346349443,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('jnn516ill7uur3dmaa0j6b90o7',1346783263,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('jobfv1d8m7nsustmpg9kess5d1',1346252710,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('jsf2ln2voh4urbjqtbrtcge0n6',1346351987,1209600,'flash|a:1:{s:6:\"status\";N;}'),('ju46n6l92ongo69eiber3mib23',1346786277,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('jujqq5akvqs9h200g7p3ah6pb3',1346349353,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('k0oo39k2m6qj7m8cea8q9gad33',1346785782,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('k1ftmie0gr8715kamrtbkct651',1346352038,1209600,'flash|a:1:{s:6:\"status\";N;}'),('k27pi3ku3s000ti17s8brr9d72',1346785696,1209600,'flash|a:1:{s:6:\"status\";N;}'),('k9rh649a14fvuh30i7q1r9ngq3',1346252871,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('kmesqp102gleapkcq4vc15u9i5',1346349143,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ko8v99f6nvjvllrccj275280b7',1346790372,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}'),('l36bkii605fjep75m5ece95tp6',1346251759,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('l50d082nn1m4k0o64abk42g2l2',1346252345,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('l5v7ct52n28d1t3jmdgsm3t6c3',1346252751,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('l9qckdrq0prssqo7tk1g92svl6',1346938617,1209600,'Default|a:1:{s:8:\"redirect\";s:13:\"/items/browse\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}'),('la1hvbf9p5lmej7ob4mh5b4pr0',1346782956,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('lfl2r9rvbn1hp5lkgdh3k8n407',1346349627,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('lpj12p2a42qrpko02jkt4nss33',1346785932,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('lvn9svnq8e338jhqck1nc0ntg1',1346786195,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('m6l0u3eke0rlclmr3djlqghmn4',1346786292,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('mo0ipoqebeadj9plqn4kv8qfn1',1346252800,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('mpli6oakqgkjjcar0i8ll4nhp4',1346783914,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('muu9o76cjp48nhft7doaqcggt4',1346350483,1209600,''),('n0sprdfij01ag4p93bjm7cad53',1346786308,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('n72pbo4js1rbqng9fqg9p6tl03',1346348779,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('nb67ihoprpodphe86pkufs8k51',1346349250,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('neo3er7frr0m9at2ko1jn4p5o3',1346252431,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('nkbpetb8i29mptiiuvchlg0ho6',1346792164,1209600,''),('og4nr4grvatiamid4br75243g4',1346252122,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ol586r84r2gs13hjvipj83stg2',1346252041,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('op949udpnehce4o24ckmcfhh75',1346790587,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}flash|a:1:{s:6:\"status\";N;}'),('pc276346friebm05a1svt2lgj6',1346783751,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('pffbnrb69eoghrtp6cl1mtgqv6',1346349305,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('pg49uulugv00c6rnoiac04idj4',1346783907,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('pi2b8diu6uuhd24b7g9pl5h105',1346252301,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('pmn1r68lluc6mbaav3d0nomi57',1346252406,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('qb11dmqu6rhoef2q4e65gdq973',1346351769,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('qbat7h5kokaauq4sroadrfebr3',1346786622,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('qbi3tpao1dstn1cqr84mct3cb3',1346786210,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('qgjalv978akjidni5q92rs7cs2',1346786227,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('qp2itign5eq7dpeq2isq48mmo1',1346786006,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('r3q51o7s7ko0l5sum1iaklidg7',1346348971,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('r7rvih4c7ug3q5ia1e4k7flkm0',1346790560,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}'),('ra687m6t1qt49lf2ka9e6io1e0',1346252468,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ran09imkj1smkirkbb1fl6j0s7',1346251942,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('s8r3gj9ltvomepb378cejch820',1346782476,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('sas9r3gbstorv5j3u05mkl16l0',1346786287,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('sd8l48bml70lr1ltph6g873852',1346350669,1209600,'flash|a:1:{s:6:\"status\";N;}'),('t1ggp1bckpe9shhburrq6i7rp7',1346349272,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('t3omc4kcncr642us81dea0lsp4',1346786272,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('t9b7a1nmfvg1eml5jl59dk4qc3',1346357070,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}flash|a:1:{s:6:\"status\";N;}'),('tl1inmo00bhkll31e8jmm0l6m0',1346255783,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('tm0hdfv6fe1uab7vk6nlol63m4',1346783616,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('tnd2fv93ct74cu7cl6ivs96i95',1346785527,1209600,'flash|a:1:{s:6:\"status\";N;}'),('u41f07sno48j7rc2orgtuaqh22',1346348812,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('u4jlbkvugv46phbluksgfuujn2',1346252413,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('u6v642330f7k7es1pgqsp36h11',1346349290,1209600,'Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}flash|a:1:{s:6:\"status\";N;}'),('ued4iniefmdimkpjmv74k1cv70',1346782918,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('ufi16phps7h7tcjg74n6o6b5t4',1346783481,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('us4bi1bdt00mpndft077q8cgi0',1346789880,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}'),('v15nk1gkake7a5lma2591n04b1',1346357477,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('vc473depbc5rt0kmkphjiulpp6',1346785530,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('vk6qta5oj50t5opk4ftcv0fie6',1346350507,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('vlf0j0108fdapcubf1prc3u680',1346782688,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('vng60nhgpj2ui28dd26judp6r0',1346782847,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}'),('vqtqpd4g58a6sp00b40nr6h336',1346783992,1209600,'flash|a:1:{s:6:\"status\";N;}Zend_Auth|a:1:{s:7:\"storage\";i:1;}Default|a:1:{s:8:\"redirect\";N;}');
/*!40000 ALTER TABLE `omeka_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_taggings`
--

DROP TABLE IF EXISTS `omeka_taggings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_taggings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `relation_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  `entity_id` int(10) unsigned NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag` (`relation_id`,`tag_id`,`entity_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_taggings`
--

LOCK TABLES `omeka_taggings` WRITE;
/*!40000 ALTER TABLE `omeka_taggings` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_taggings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_tags`
--

DROP TABLE IF EXISTS `omeka_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_tags`
--

LOCK TABLES `omeka_tags` WRITE;
/*!40000 ALTER TABLE `omeka_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_users`
--

DROP TABLE IF EXISTS `omeka_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `role` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `entity_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `active_idx` (`active`),
  KEY `entity_id` (`entity_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_users`
--

LOCK TABLES `omeka_users` WRITE;
/*!40000 ALTER TABLE `omeka_users` DISABLE KEYS */;
INSERT INTO `omeka_users` VALUES (1,'neatline','4ba1778d5485a39685721de7bf18e79cbedde574','6e2567ece63d017d',1,'super',1);
/*!40000 ALTER TABLE `omeka_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_users_activations`
--

DROP TABLE IF EXISTS `omeka_users_activations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_users_activations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_users_activations`
--

LOCK TABLES `omeka_users_activations` WRITE;
/*!40000 ALTER TABLE `omeka_users_activations` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_users_activations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-09-06 15:43:51
